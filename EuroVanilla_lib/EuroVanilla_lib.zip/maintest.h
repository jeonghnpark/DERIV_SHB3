#pragma once
double __stdcall plus4(double i);