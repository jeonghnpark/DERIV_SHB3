#include "maintest.h"

double __stdcall plus4(double i)
{
	return i+4;
}
