#pragma once
#include <vector>
class FDM {
private:
	std::vector<double> vold;
	std::vector<double> px;
	int min;
	int max;
public:
};