#include <iostream>
#include <cstdlib>
#include "volatility.h"
#include "MarketParam.h"
#include "MarketParameters.h"
#include "PayoffPut.h"
#include "PayoffCall.h"
#include "EuropeanOption.h"
#include "AmericanOption.h"
#include <vector> 
#include "k_OptionFormula.hpp"
#include "PayoffBarCUO.h"
#include "BarrierOption.h"
#include "AutocallOption.h"
#include <chrono>
#include "EuropeanOptionMC.h"
#include "AsianOption.h"
#include "Dividend.h"

using namespace std;

enum FvsS{flat,surface};
enum CalcMode{calc1,calc2};


void test_american(double spot)
{

	double arr_rts[] = { 0.002739726,0.25,0.5,0.75,1,1.5,2,2.5,3,4,5,7,10,15,20 };
	double arr_r[] = { 1.54,1.64,1.72,1.77,1.8,1.85,1.88,1.90,1.92,1.92,1.92,1.92,1.92,1.92,1.92 };
	for (int i = 0; i<15; i++)
		arr_r[i] /= 100.0;

	double arr_qts[] = { 0.0191780821917808,0.038356164,0.057534247,0.084931507,0.104109589,0.123287671,0.142465753,0.167123288,0.252054795,0.334246575,0.419178082,0.504109589,0.580821918,0.665753425,0.747945205,0.832876712,0.915068493,1,1.084931507,1.167123288,1.252054795,1.334246575,1.419178082,1.504109589,1.583561644,1.668493151,1.750684932,1.835616438,1.917808219,	2.002739726	,2.087671233,2.169863014,2.254794521,2.336986301,2.421917808,2.506849315,2.583561644,2.668493151,2.750684932,2.835616438,2.917808219,3.002739726 };
	double arr_q[] = { 0.00000,0.00000,0.00000,2.57097, 2.09737,1.77112,1.53270, 1.30656 ,0.86631 ,5.16283, 4.11677,3.42318,3.34816,2.92103,2.60139,2.67302,2.43293,2.22630,2.26258, 2.10325,1.96057,3.00733,2.82806 ,2.66837, 2.53449,2.53675,2.41823 ,2.46233 ,2.35680 ,2.25685 ,2.27446 ,2.18831 ,2.10588 ,2.66917,2.57598,2.48871,2.41481,2.42319,2.35115 ,2.38170 ,2.31461 ,2.24914 };
	for (int i = 0; i<42; i++)
		arr_q[i] /= 100.0;

	//double spot=297.22;
	double vol_term[] = { 0.08493150,0.16712330,0.25205480,0.50410960,0.74794520,1.00000000,1.50410960,2.00273970,2.50684930,3.00273970 }; //10terms
	double vol_strike[] = { 178.332,193.193,208.054,222.915,237.776,252.637,267.498,282.359,297.22,312.081,326.942,341.803,356.664,371.525,386.386,401.247,416.108 };//17spot
	Vol volat(10, 17);
	double t0[] = { 0.3095,0.2907,0.2719,0.2528,0.2331,0.2136,0.1816,0.1388,0.1081,0.105,0.1296,0.1606,0.1795,0.1892,0.1978,0.2057,0.2129 };
	double t1[] = { 0.2807,0.2619,0.2431,0.2239,0.2042,0.1845,0.1586,0.1285,0.1095,0.1027,0.1076,0.1306,0.1518,0.1634,0.172,0.1798,0.1869 };
	double t2[] = { 0.2621,0.2448,0.2274,0.2098,0.1916,0.172,0.1505,0.128,0.1131,0.1076,0.1125,0.1264,0.1413,0.1517,0.16,0.1676,0.1745 };
	double t3[] = { 0.2376,0.2219,0.2061,0.1902,0.1741,0.1576,0.141,0.1261,0.1169,0.1161,0.1215,0.1292,0.1371,0.1447,0.1517,0.1583,0.1644 };
	double t4[] = { 0.2286,0.214,0.1997,0.1854,0.1712,0.1571,0.1437,0.1319,0.1238,0.1211,0.1231,0.128,0.1339,0.14,0.146,0.1517,0.1571 };
	double t5[] = { 0.221,0.2077,0.1946,0.1819,0.1694,0.1574,0.1462,0.1366,0.1295,0.1261,0.1261,0.1287,0.1327,0.1374,0.1422,0.1469,0.1516 };
	double t6[] = { 0.2063,0.1949,0.1841,0.1737,0.1639,0.1549,0.1469,0.1403,0.1355,0.1329,0.1322,0.1331,0.1352,0.1379,0.1409,0.1442,0.1475 };
	double t7[] = { 0.1993,0.1897,0.1806,0.1721,0.1642,0.157,0.1506,0.1453,0.1411,0.1383,0.1368,0.1364,0.1369,0.1381,0.1398,0.1418,0.144 };
	double t8[] = { 0.1927,0.1844,0.1768,0.1696,0.1631,0.1572,0.1521,0.1477,0.1443,0.1418,0.1402,0.1394,0.1393,0.1398,0.1407,0.1419,0.1434 };
	double t9[] = { 0.1892,0.182,0.1754,0.1692,0.1637,0.1586,0.1542,0.1505,0.1474,0.145,0.1432,0.1421,0.1415,0.1414,0.1417,0.1423,0.1431 };

	volat.set_vol_strike(vol_strike, 17);
	volat.set_vol_term(vol_term, 10);

	volat.set_volsurface_by_term(t0, 0, 17);
	volat.set_volsurface_by_term(t1, 1, 17);
	volat.set_volsurface_by_term(t2, 2, 17);
	volat.set_volsurface_by_term(t3, 3, 17);
	volat.set_volsurface_by_term(t4, 4, 17);
	volat.set_volsurface_by_term(t5, 5, 17);
	volat.set_volsurface_by_term(t6, 6, 17);
	volat.set_volsurface_by_term(t7, 7, 17);
	volat.set_volsurface_by_term(t8, 8, 17);
	volat.set_volsurface_by_term(t9, 9, 17);

	std::vector<double> v_rts(std::begin(arr_rts), std::end(arr_rts));
	std::vector<double> v_r(std::begin(arr_r), std::end(arr_r));
	std::vector<double> v_qts(std::begin(arr_qts), std::end(arr_qts));
	std::vector<double> v_q(std::begin(arr_q), std::end(arr_q));

	Rate r(v_r, v_rts);
	Rate q(v_q, v_qts);

	double refprice = 297.22;
	double rf_for_bs = r.getIntpRate(1.0);
	double div_for_bs = q.getIntpRate(1.0);
	double putstrike = 297.22*0.9;
	double callstrike = 297.22*1.1;
	double intpvol = volat.getInpVol(1.0, putstrike);

	MarketParam para(0, spot, volat, r, q);

	PayoffPut putpay(putstrike);
	//EuropeanOption EurPut(refprice, 365, putpay);
	//EurPut.Calc(para);
	AmericanOption AmPut(refprice, 365, putpay);
	AmPut.Calc(para);

	/*EuropeanVanilla Vput(putpay,refprice, ed);

	EuropeanPut eput(refprice,putstrike,365);
	EuropeanCall ecall(refprice,callstrike,365);

	*/
	std::cout.precision(8);
	std::cout << std::fixed;

	//std::cout <<"eput:  s=" <<spot<<" "<< eput.pv(para)<<" vol " << volat.getInpVol(365/365,putstrike)<< "r " << r.getIntpRate(1.0) << " q " << q.getIntpRate(1.0) <<  std::endl;
	//std::cout <<"ecall: "<< ecall.pv(para)<< "s= " <<spot<<" "<<" vol " <<volat.getInpVol(365/365,callstrike)<< " r " << r.getIntpRate(1.0) << " q " << q.getIntpRate(1.0) << std::endl;
	std::vector<double> rs = AmPut.GetResult();

	std::cout << "pv(AMERICAN) " << rs[0] << std::endl;
	std::cout << "delta " << rs[1] << std::endl;
	std::cout << "gamma " << rs[2] << std::endl;
	std::cout << "spot " << rs[5] << std::endl;
	std::cout << "BS vol=" << volat.getBSVol(365 / 365, putpay.GetStrike()) << std::endl;
	std::cout << "implied vol=" << put_iv(spot, putstrike, rf_for_bs, div_for_bs, 0.1, 1.0, rs[0]) << std::endl;
	//std::cout << "delta(closed, Flatvol)=" << k_fmla_BSPutDelta(spot, putstrike, rf_for_bs, div_for_bs, volat.getBSVol(1.0, putpay.GetStrike()), 1.0) << std::endl;
	//std::cout << "gamma(closed, Flatvol)=" << k_fmla_BSGamma(spot, putstrike, rf_for_bs, div_for_bs, volat.getBSVol(1.0, putpay.GetStrike()), 1.0) << std::endl;

	std::cout << "\n";

	//Vol volat_up(volat);
	//volat_up.Vol_up(0.01);
	//MarketParam para_volup(0, spot, volat_up, r, q);
	////EuropeanOption EurPut_vega(refprice, 365, putpay);
	//EurPut_vega.Calc(para_volup);

	//std::vector<double> rs_vega = AmPut_vega.GetResult();
	//std::cout << "pv(AMERICAN)(for vega)" << rs_vega[0] << std::endl;
	//std::cout << "delta(for vega) " << rs_vega[1] << std::endl;
	//std::cout << "gamma(for vega) " << rs_vega[2] << std::endl;
	//std::cout << "spot(for vega) " << rs_vega[5] << std::endl;
	//std::cout << "BS vol(for vega)=" << volat_up.getBSVol(365 / 365, putpay.GetStrike()) << std::endl;
	//std::cout << "implied vol(for vega)=" << put_iv(spot, putstrike, rf_for_bs, div_for_bs, 0.1, 1.0, rs_vega[0]) << std::endl;
	////std::cout << "delta(for vega)(closed, Flatvol)=" << k_fmla_BSPutDelta(spot, putstrike, rf_for_bs, div_for_bs, volat_up.getBSVol(1.0, putpay.GetStrike()), 1.0) << std::endl;
	////std::cout << "gamma(for vega)(closed, Flatvol)=" << k_fmla_BSGamma(spot, putstrike, rf_for_bs, div_for_bs, volat_up.getBSVol(1.0, putpay.GetStrike()), 1.0) << std::endl;
	////std::cout << "\n";

	////std::cout << "vega(closed, Flatvol)=" << k_fmla_BSVega(spot, putstrike, rf_for_bs, div_for_bs, volat.getBSVol(1.0, putpay.GetStrike()), 1.0) / 100.0 << std::endl;
	////std::cout << "vega(for vega) " << rs_vega[0] - rs[0] << std::endl;


}
void test_europeanMC(double spot)
{
	
}
void test_european(double spot, long numMC)
{
	
	double arr_rts[]={0.002739726,0.25,0.5,0.75,1,1.5,2,2.5,3,4,5,7,10,15,20};
	double arr_r[]={1.54,1.64,1.72,1.77,1.8,1.85,1.88,1.90,1.92,1.92,1.92,1.92,1.92,1.92,1.92};
	for(int i=0;i<15;i++)
		arr_r[i]/=100.0;

	double arr_qts[]={0.0191780821917808,0.038356164,0.057534247,0.084931507,0.104109589,0.123287671,0.142465753,0.167123288,0.252054795,0.334246575,0.419178082,0.504109589,0.580821918,0.665753425,0.747945205,0.832876712,0.915068493,1,1.084931507,1.167123288,1.252054795,1.334246575,1.419178082,1.504109589,1.583561644,1.668493151,1.750684932,1.835616438,1.917808219,	2.002739726	,2.087671233,2.169863014,2.254794521,2.336986301,2.421917808,2.506849315,2.583561644,2.668493151,2.750684932,2.835616438,2.917808219,3.002739726};
	double arr_q[]={0.00000,0.00000,0.00000,2.57097, 2.09737,1.77112,1.53270, 1.30656 ,0.86631 ,5.16283, 4.11677,3.42318,3.34816,2.92103,2.60139,2.67302,2.43293,2.22630,2.26258, 2.10325,1.96057,3.00733,2.82806 ,2.66837, 2.53449,2.53675,2.41823 ,2.46233 ,2.35680 ,2.25685 ,2.27446 ,2.18831 ,2.10588 ,2.66917,2.57598,2.48871,2.41481,2.42319,2.35115 ,2.38170 ,2.31461 ,2.24914 };
	for(int i=0;i<42;i++)
		arr_q[i]/=100.0;

	//double spot=297.22;
	double vol_term[]={0.08493150,0.16712330,0.25205480,0.50410960,0.74794520,1.00000000,1.50410960,2.00273970,2.50684930,3.00273970}; //10terms
	double vol_strike[]={178.332,193.193,208.054,222.915,237.776,252.637,267.498,282.359,297.22,312.081,326.942,341.803,356.664,371.525,386.386,401.247,416.108};//17spot
	Vol volat(10,17);
	double t0[]={0.3095,0.2907,0.2719,0.2528,0.2331,0.2136,0.1816,0.1388,0.1081,0.105,0.1296,0.1606,0.1795,0.1892,0.1978,0.2057,0.2129};
	double t1[]={0.2807,0.2619,0.2431,0.2239,0.2042,0.1845,0.1586,0.1285,0.1095,0.1027,0.1076,0.1306,0.1518,0.1634,0.172,0.1798,0.1869};
	double t2[]={0.2621,0.2448,0.2274,0.2098,0.1916,0.172,0.1505,0.128,0.1131,0.1076,0.1125,0.1264,0.1413,0.1517,0.16,0.1676,0.1745};
	double t3[]={0.2376,0.2219,0.2061,0.1902,0.1741,0.1576,0.141,0.1261,0.1169,0.1161,0.1215,0.1292,0.1371,0.1447,0.1517,0.1583,0.1644};
	double t4[]={0.2286,0.214,0.1997,0.1854,0.1712,0.1571,0.1437,0.1319,0.1238,0.1211,0.1231,0.128,0.1339,0.14,0.146,0.1517,0.1571};
	double t5[]={0.221,0.2077,0.1946,0.1819,0.1694,0.1574,0.1462,0.1366,0.1295,0.1261,0.1261,0.1287,0.1327,0.1374,0.1422,0.1469,0.1516};
	double t6[]={0.2063,0.1949,0.1841,0.1737,0.1639,0.1549,0.1469,0.1403,0.1355,0.1329,0.1322,0.1331,0.1352,0.1379,0.1409,0.1442,0.1475};
	double t7[]={0.1993,0.1897,0.1806,0.1721,0.1642,0.157,0.1506,0.1453,0.1411,0.1383,0.1368,0.1364,0.1369,0.1381,0.1398,0.1418,0.144};
	double t8[]={0.1927,0.1844,0.1768,0.1696,0.1631,0.1572,0.1521,0.1477,0.1443,0.1418,0.1402,0.1394,0.1393,0.1398,0.1407,0.1419,0.1434};
	double t9[]={0.1892,0.182,0.1754,0.1692,0.1637,0.1586,0.1542,0.1505,0.1474,0.145,0.1432,0.1421,0.1415,0.1414,0.1417,0.1423,0.1431};

	volat.set_vol_strike(vol_strike, 17);
	volat.set_vol_term(vol_term,10);
	
	volat.set_volsurface_by_term(t0,0,17);
	volat.set_volsurface_by_term(t1,1,17);
	volat.set_volsurface_by_term(t2,2,17);
	volat.set_volsurface_by_term(t3,3,17);
	volat.set_volsurface_by_term(t4,4,17);
	volat.set_volsurface_by_term(t5,5,17);
	volat.set_volsurface_by_term(t6,6,17);
	volat.set_volsurface_by_term(t7,7,17);
	volat.set_volsurface_by_term(t8,8,17);
	volat.set_volsurface_by_term(t9,9,17);

	std::vector<double> v_rts(std::begin(arr_rts), std::end(arr_rts));
	std::vector<double> v_r(std::begin(arr_r), std::end(arr_r));
	std::vector<double> v_qts(std::begin(arr_qts), std::end(arr_qts));
	std::vector<double> v_q(std::begin(arr_q), std::end(arr_q));

	Rate r(v_r,v_rts);
	Rate q(v_q,v_qts);
	
	double refprice=297.22;
	double rf_for_bs=r.getIntpRate(1.0);
	double div_for_bs=q.getIntpRate(1.0);
	double putstrike=297.22*0.9;
	double callstrike=297.22*1.1;
	double intpvol=volat.getInpVol(1.0,putstrike);
	
	MarketParam para(43340,spot,volat,r,q);

	PayoffPut putpay(putstrike);
	EuropeanOption EurPut(refprice,43705,putpay);
	EuropeanOptionMC EurPutMC(refprice, 43705, putpay);

	EurPut.Calc(para);
	EurPutMC.Calc(para,numMC);
	/*EuropeanVanilla Vput(putpay,refprice, ed);

	EuropeanPut eput(refprice,putstrike,365);
	EuropeanCall ecall(refprice,callstrike,365);
	
	*/
	std::cout.precision(8);
	std::cout <<std::fixed;

	//std::cout <<"eput:  s=" <<spot<<" "<< eput.pv(para)<<" vol " << volat.getInpVol(365/365,putstrike)<< "r " << r.getIntpRate(1.0) << " q " << q.getIntpRate(1.0) <<  std::endl;
	//std::cout <<"ecall: "<< ecall.pv(para)<< "s= " <<spot<<" "<<" vol " <<volat.getInpVol(365/365,callstrike)<< " r " << r.getIntpRate(1.0) << " q " << q.getIntpRate(1.0) << std::endl;
	std::vector<double> rs=EurPut.GetResult();
	
	std::cout<< "pv "<<rs[0]<<std::endl;
	std::cout<< "delta "<<rs[1]<<std::endl;
	std::cout<< "gamma "<<rs[2]<<std::endl;
	std::cout << "spot " <<rs[5]<<std::endl;
	std::cout<< "BS vol="<<volat.getBSVol(365/365, putpay.GetStrike())<<std::endl;
	std::cout << "implied vol="<<put_iv(spot,putstrike,rf_for_bs, div_for_bs,0.1,(43705-43340)/365,rs[0])<<std::endl;
	std::cout << "delta(closed, Flatvol)="<<k_fmla_BSPutDelta(spot,putstrike,rf_for_bs, div_for_bs,volat.getBSVol(1.0, putpay.GetStrike()),1.0)<<std::endl;
	std::cout << "gamma(closed, Flatvol)="<<k_fmla_BSGamma(spot,putstrike,rf_for_bs, div_for_bs,volat.getBSVol(1.0, putpay.GetStrike()),1.0)<<std::endl;
	std::cout<<"\n";

	std::vector<double> rsMc = EurPutMC.GetResult();

	std::cout << "pv MC " << rsMc[0] << std::endl;
	std::cout << "delta MC " << rsMc[1] << std::endl;
	std::cout << "gamma MC" << rsMc[2] << std::endl;
	std::cout << "spot " << rsMc[5] << std::endl;
	std::cout << "BS vol=" << volat.getBSVol(365 / 365, putpay.GetStrike()) << std::endl;
	std::cout << "implied vol=" << put_iv(spot, putstrike, rf_for_bs, div_for_bs, 0.1, 1.0, rs[0]) << std::endl;
	std::cout << "delta(closed, Flatvol)=" << k_fmla_BSPutDelta(spot, putstrike, rf_for_bs, div_for_bs, volat.getBSVol(1.0, putpay.GetStrike()), 1.0) << std::endl;
	std::cout << "gamma(closed, Flatvol)=" << k_fmla_BSGamma(spot, putstrike, rf_for_bs, div_for_bs, volat.getBSVol(1.0, putpay.GetStrike()), 1.0) << std::endl;
	std::cout << "\n";

	Vol volat_up(volat);
	volat_up.Vol_up(0.01);
	MarketParam para_volup(0,spot,volat_up,r,q);
	EuropeanOption EurPut_vega(refprice,365,putpay);
	EurPut_vega.Calc(para_volup);

	std::vector<double> rs_vega=EurPut_vega.GetResult();
	std::cout<< "pv(for vega)"<<rs_vega[0]<<std::endl;
	std::cout<< "delta(for vega) "<<rs_vega[1]<<std::endl;
	std::cout<< "gamma(for vega) "<<rs_vega[2]<<std::endl;
	std::cout << "spot(for vega) " <<rs_vega[5]<<std::endl;
	std::cout<< "BS vol(for vega)="<<volat_up.getBSVol(365/365, putpay.GetStrike())<<std::endl;
	std::cout << "implied vol(for vega)="<<put_iv(spot,putstrike,rf_for_bs, div_for_bs,0.1,1.0,rs_vega[0])<<std::endl;
	std::cout << "delta(for vega)(closed, Flatvol)="<<k_fmla_BSPutDelta(spot,putstrike,rf_for_bs, div_for_bs,volat_up.getBSVol(1.0, putpay.GetStrike()),1.0)<<std::endl;
	std::cout << "gamma(for vega)(closed, Flatvol)="<<k_fmla_BSGamma(spot,putstrike,rf_for_bs, div_for_bs,volat_up.getBSVol(1.0, putpay.GetStrike()),1.0)<<std::endl;
	std::cout<<"\n";

	std::cout << "vega(closed, Flatvol)="<<k_fmla_BSVega(spot,putstrike,rf_for_bs, div_for_bs,volat.getBSVol(1.0, putpay.GetStrike()),1.0)/100.0<<std::endl;
	std::cout<< "vega(for vega) "<<rs_vega[0]-rs[0]<<std::endl;
	
	
}



void test_asian(double spot, long numMC)
{

	double arr_rts[] = { 0.002739726,0.25,0.5,0.75,1,1.5,2,2.5,3,4,5,7,10,15,20 };
	double arr_r[] = { 1.54,1.64,1.72,1.77,1.8,1.85,1.88,1.90,1.92,1.92,1.92,1.92,1.92,1.92,1.92 };
	for (int i = 0; i<15; i++)
		arr_r[i] /= 100.0;

	double arr_qts[] = { 0.0191780821917808,0.038356164,0.057534247,0.084931507,0.104109589,0.123287671,0.142465753,0.167123288,0.252054795,0.334246575,0.419178082,0.504109589,0.580821918,0.665753425,0.747945205,0.832876712,0.915068493,1,1.084931507,1.167123288,1.252054795,1.334246575,1.419178082,1.504109589,1.583561644,1.668493151,1.750684932,1.835616438,1.917808219,	2.002739726	,2.087671233,2.169863014,2.254794521,2.336986301,2.421917808,2.506849315,2.583561644,2.668493151,2.750684932,2.835616438,2.917808219,3.002739726 };
	double arr_q[] = { 0.00000,0.00000,0.00000,2.57097, 2.09737,1.77112,1.53270, 1.30656 ,0.86631 ,5.16283, 4.11677,3.42318,3.34816,2.92103,2.60139,2.67302,2.43293,2.22630,2.26258, 2.10325,1.96057,3.00733,2.82806 ,2.66837, 2.53449,2.53675,2.41823 ,2.46233 ,2.35680 ,2.25685 ,2.27446 ,2.18831 ,2.10588 ,2.66917,2.57598,2.48871,2.41481,2.42319,2.35115 ,2.38170 ,2.31461 ,2.24914 };
	for (int i = 0; i<42; i++)
		arr_q[i] /= 100.0;

	//double spot=297.22;
	double vol_term[] = { 0.08493150,0.16712330,0.25205480,0.50410960,0.74794520,1.00000000,1.50410960,2.00273970,2.50684930,3.00273970 }; //10terms
	double vol_strike[] = { 178.332,193.193,208.054,222.915,237.776,252.637,267.498,282.359,297.22,312.081,326.942,341.803,356.664,371.525,386.386,401.247,416.108 };//17spot
	Vol volat(10, 17);
	double t0[] = { 0.3095,0.2907,0.2719,0.2528,0.2331,0.2136,0.1816,0.1388,0.1081,0.105,0.1296,0.1606,0.1795,0.1892,0.1978,0.2057,0.2129 };
	double t1[] = { 0.2807,0.2619,0.2431,0.2239,0.2042,0.1845,0.1586,0.1285,0.1095,0.1027,0.1076,0.1306,0.1518,0.1634,0.172,0.1798,0.1869 };
	double t2[] = { 0.2621,0.2448,0.2274,0.2098,0.1916,0.172,0.1505,0.128,0.1131,0.1076,0.1125,0.1264,0.1413,0.1517,0.16,0.1676,0.1745 };
	double t3[] = { 0.2376,0.2219,0.2061,0.1902,0.1741,0.1576,0.141,0.1261,0.1169,0.1161,0.1215,0.1292,0.1371,0.1447,0.1517,0.1583,0.1644 };
	double t4[] = { 0.2286,0.214,0.1997,0.1854,0.1712,0.1571,0.1437,0.1319,0.1238,0.1211,0.1231,0.128,0.1339,0.14,0.146,0.1517,0.1571 };
	double t5[] = { 0.221,0.2077,0.1946,0.1819,0.1694,0.1574,0.1462,0.1366,0.1295,0.1261,0.1261,0.1287,0.1327,0.1374,0.1422,0.1469,0.1516 };
	double t6[] = { 0.2063,0.1949,0.1841,0.1737,0.1639,0.1549,0.1469,0.1403,0.1355,0.1329,0.1322,0.1331,0.1352,0.1379,0.1409,0.1442,0.1475 };
	double t7[] = { 0.1993,0.1897,0.1806,0.1721,0.1642,0.157,0.1506,0.1453,0.1411,0.1383,0.1368,0.1364,0.1369,0.1381,0.1398,0.1418,0.144 };
	double t8[] = { 0.1927,0.1844,0.1768,0.1696,0.1631,0.1572,0.1521,0.1477,0.1443,0.1418,0.1402,0.1394,0.1393,0.1398,0.1407,0.1419,0.1434 };
	double t9[] = { 0.1892,0.182,0.1754,0.1692,0.1637,0.1586,0.1542,0.1505,0.1474,0.145,0.1432,0.1421,0.1415,0.1414,0.1417,0.1423,0.1431 };

	volat.set_vol_strike(vol_strike, 17);
	volat.set_vol_term(vol_term, 10);

	volat.set_volsurface_by_term(t0, 0, 17);
	volat.set_volsurface_by_term(t1, 1, 17);
	volat.set_volsurface_by_term(t2, 2, 17);
	volat.set_volsurface_by_term(t3, 3, 17);
	volat.set_volsurface_by_term(t4, 4, 17);
	volat.set_volsurface_by_term(t5, 5, 17);
	volat.set_volsurface_by_term(t6, 6, 17);
	volat.set_volsurface_by_term(t7, 7, 17);
	volat.set_volsurface_by_term(t8, 8, 17);
	volat.set_volsurface_by_term(t9, 9, 17);

	std::vector<double> v_rts(std::begin(arr_rts), std::end(arr_rts));
	std::vector<double> v_r(std::begin(arr_r), std::end(arr_r));
	std::vector<double> v_qts(std::begin(arr_qts), std::end(arr_qts));
	std::vector<double> v_q(std::begin(arr_q), std::end(arr_q));

	Rate r(v_r, v_rts);
	Rate q(v_q, v_qts);

	double refprice = 297.22;
	double rf_for_bs = r.getIntpRate(1.0);
	double div_for_bs = q.getIntpRate(1.0);
	double putstrike = 297.22*0.9;
	double callstrike = 297.22*1.1;
	double intpvol = volat.getInpVol(1.0, putstrike);

	MarketParam para(43340, spot, volat, r, q);

	PayoffPut putpay(putstrike);
	

	EuropeanOption EurPut(refprice, 43705, putpay);
	//vector<signed int> od{43432,43524,43613,43705};
	vector<signed int> od{ 43524,43705 };


	AsianOption Asian(refprice, 43705 ,putpay,od);
	Asian.Calc(para, numMC);
	EurPut.Calc(para);

	/*EuropeanVanilla Vput(putpay,refprice, ed);

	EuropeanPut eput(refprice,putstrike,365);
	EuropeanCall ecall(refprice,callstrike,365);

	*/
	std::cout.precision(8);
	std::cout << std::fixed;

	//std::cout <<"eput:  s=" <<spot<<" "<< eput.pv(para)<<" vol " << volat.getInpVol(365/365,putstrike)<< "r " << r.getIntpRate(1.0) << " q " << q.getIntpRate(1.0) <<  std::endl;
	//std::cout <<"ecall: "<< ecall.pv(para)<< "s= " <<spot<<" "<<" vol " <<volat.getInpVol(365/365,callstrike)<< " r " << r.getIntpRate(1.0) << " q " << q.getIntpRate(1.0) << std::endl;
	std::vector<double> rs = Asian.GetResult();
	std::vector<double> euro_rs = EurPut.GetResult();

	std::cout << "   " <<"Asian " << "        "  << "european" << std::endl;
	std::cout << "pv " << rs[0] << "   " << euro_rs[0] <<std::endl;
	std::cout << "delta " << rs[1] << "  " << euro_rs[1]  << std::endl;
	std::cout << "gamma " << rs[2] <<  "  "  << euro_rs[2] << std::endl;
	std::cout << "spot " << rs[5] << std::endl;
	std::cout << "BS vol=" << volat.getBSVol(365 / 365, putpay.GetStrike()) << std::endl;
	std::cout << "implied vol=" << put_iv(spot, putstrike, rf_for_bs, div_for_bs, 0.1, 1.0, rs[0]) << std::endl;
	std::cout << "delta(closed, Flatvol)=" << k_fmla_BSPutDelta(spot, putstrike, rf_for_bs, div_for_bs, volat.getBSVol(1.0, putpay.GetStrike()), 1.0) << std::endl;
	std::cout << "gamma(closed, Flatvol)=" << k_fmla_BSGamma(spot, putstrike, rf_for_bs, div_for_bs, volat.getBSVol(1.0, putpay.GetStrike()), 1.0) << std::endl;

	std::cout << "\n";


}

void test_barrier_flat(double spot)
{
	double arr_rts[] = { 0.002739726,0.25,0.5,0.75,1,1.5,2,2.5,3,4,5,7,10,15,20 };
	double arr_r[] = { 1.54,1.64,1.72,1.77,1.8,1.85,1.88,1.90,1.92,1.92,1.92,1.92,1.92,1.92,1.92 };
	for (int i = 0; i<15; i++)
		arr_r[i] /= 100.0;

	double arr_qts[] = { 0.0191780821917808,0.038356164,0.057534247,0.084931507,0.104109589,0.123287671,0.142465753,0.167123288,0.252054795,0.334246575,0.419178082,0.504109589,0.580821918,0.665753425,0.747945205,0.832876712,0.915068493,1,1.084931507,1.167123288,1.252054795,1.334246575,1.419178082,1.504109589,1.583561644,1.668493151,1.750684932,1.835616438,1.917808219,	2.002739726	,2.087671233,2.169863014,2.254794521,2.336986301,2.421917808,2.506849315,2.583561644,2.668493151,2.750684932,2.835616438,2.917808219,3.002739726 };
	double arr_q[] = { 0.00000,0.00000,0.00000,2.57097, 2.09737,1.77112,1.53270, 1.30656 ,0.86631 ,5.16283, 4.11677,3.42318,3.34816,2.92103,2.60139,2.67302,2.43293,2.22630,2.26258, 2.10325,1.96057,3.00733,2.82806 ,2.66837, 2.53449,2.53675,2.41823 ,2.46233 ,2.35680 ,2.25685 ,2.27446 ,2.18831 ,2.10588 ,2.66917,2.57598,2.48871,2.41481,2.42319,2.35115 ,2.38170 ,2.31461 ,2.24914 };
	for (int i = 0; i<42; i++)
		arr_q[i] /= 100.0;

	//double spot=297.22;
	double vol_term[] = { 0.08493150,0.16712330,0.25205480,0.50410960,0.74794520,1.00000000,1.50410960,2.00273970,2.50684930,3.00273970 }; //10terms
	double vol_strike[] = { 178.332,193.193,208.054,222.915,237.776,252.637,267.498,282.359,297.22,312.081,326.942,341.803,356.664,371.525,386.386,401.247,416.108 };//17spot
	Vol volat(10, 17);
	double t0[] = { 0.3095,0.2907,0.2719,0.2528,0.2331,0.2136,0.1816,0.1388,0.1081,0.105,0.1296,0.1606,0.1795,0.1892,0.1978,0.2057,0.2129 };
	double t1[] = { 0.2807,0.2619,0.2431,0.2239,0.2042,0.1845,0.1586,0.1285,0.1095,0.1027,0.1076,0.1306,0.1518,0.1634,0.172,0.1798,0.1869 };
	double t2[] = { 0.2621,0.2448,0.2274,0.2098,0.1916,0.172,0.1505,0.128,0.1131,0.1076,0.1125,0.1264,0.1413,0.1517,0.16,0.1676,0.1745 };
	double t3[] = { 0.2376,0.2219,0.2061,0.1902,0.1741,0.1576,0.141,0.1261,0.1169,0.1161,0.1215,0.1292,0.1371,0.1447,0.1517,0.1583,0.1644 };
	double t4[] = { 0.2286,0.214,0.1997,0.1854,0.1712,0.1571,0.1437,0.1319,0.1238,0.1211,0.1231,0.128,0.1339,0.14,0.146,0.1517,0.1571 };
	double t5[] = { 0.221,0.2077,0.1946,0.1819,0.1694,0.1574,0.1462,0.1366,0.1295,0.1261,0.1261,0.1287,0.1327,0.1374,0.1422,0.1469,0.1516 };
	double t6[] = { 0.2063,0.1949,0.1841,0.1737,0.1639,0.1549,0.1469,0.1403,0.1355,0.1329,0.1322,0.1331,0.1352,0.1379,0.1409,0.1442,0.1475 };
	double t7[] = { 0.1993,0.1897,0.1806,0.1721,0.1642,0.157,0.1506,0.1453,0.1411,0.1383,0.1368,0.1364,0.1369,0.1381,0.1398,0.1418,0.144 };
	double t8[] = { 0.1927,0.1844,0.1768,0.1696,0.1631,0.1572,0.1521,0.1477,0.1443,0.1418,0.1402,0.1394,0.1393,0.1398,0.1407,0.1419,0.1434 };
	double t9[] = { 0.1892,0.182,0.1754,0.1692,0.1637,0.1586,0.1542,0.1505,0.1474,0.145,0.1432,0.1421,0.1415,0.1414,0.1417,0.1423,0.1431 };

	volat.set_vol_strike(vol_strike, 17);
	volat.set_vol_term(vol_term, 10);

	volat.set_volsurface_by_term(t0, 0, 17);
	volat.set_volsurface_by_term(t1, 1, 17);
	volat.set_volsurface_by_term(t2, 2, 17);
	volat.set_volsurface_by_term(t3, 3, 17);
	volat.set_volsurface_by_term(t4, 4, 17);
	volat.set_volsurface_by_term(t5, 5, 17);
	volat.set_volsurface_by_term(t6, 6, 17);
	volat.set_volsurface_by_term(t7, 7, 17);
	volat.set_volsurface_by_term(t8, 8, 17);
	volat.set_volsurface_by_term(t9, 9, 17);

	std::vector<double> v_rts(std::begin(arr_rts), std::end(arr_rts));
	std::vector<double> v_r(std::begin(arr_r), std::end(arr_r));
	std::vector<double> v_qts(std::begin(arr_qts), std::end(arr_qts));
	std::vector<double> v_q(std::begin(arr_q), std::end(arr_q));

	Rate r(v_r, v_rts);
	Rate q(v_q, v_qts);

	double refprice = 297.22;
	double rf_for_bs = r.getIntpRate(1.0);
	double div_for_bs = q.getIntpRate(1.0);
	double putstrike = 297.22*0.9;
	double callstrike = 297.22*1.0;
	double upbarrier = 297.22*1.2;
	double intpvol = volat.getInpVol(1.0, putstrike);
	double rebate = 0.0;

	double const_vol = volat.getBSVol(1.0,297.22);
	double const_rf = r.getIntpRate(1.0);
	double const_q = q.getIntpRate(1.0);

	volat.set_const_vol(const_vol);
	r.set_const_rate(const_rf);
	q.set_const_rate(const_q);

	MarketParam para(0, spot, volat, r, q);

	PayoffBarCUO cuo(callstrike,upbarrier,rebate);
	
	BarrierOption Bar_cuo(refprice,365,cuo);

	Bar_cuo.Calc(para);

	//std::vector<double> rs = EurPut.GetResult();
	std::vector<double> rs_bar = Bar_cuo.GetResult();
	
	std::cout.precision(8);
	std::cout << std::fixed;

	std::cout << "pv " << rs_bar[0] << std::endl;
	std::cout << "delta " << rs_bar[1] << std::endl;
	std::cout << "gamma " << rs_bar[2] << std::endl;
	std::cout << "spot " << rs_bar[5] << std::endl;
	std::cout << "atm vol at ref " << volat.getBSVol(1.0, refprice) << std::endl;
	
	const double ds = 297.22*0.01;
	double clf_pv = k_fmla_Barrier(0, 0, 1, 297.22, callstrike, refprice*1.205355, const_rf, const_q, const_vol, 1.0, rebate);
	double clf_pv_up = k_fmla_Barrier(0, 0, 1, 297.22+ ds, callstrike, refprice*1.205355, const_rf, const_q, const_vol, 1.0, rebate);
	double clf_pv_down = k_fmla_Barrier(0, 0, 1, 297.22- ds, callstrike, refprice*1.205355, const_rf, const_q, const_vol, 1.0, rebate);

	std::cout << "closed form " << clf_pv << std::endl;
	std::cout << "closed form delta" << (clf_pv_up-clf_pv_down) /(ds*2.0) << std::endl;
	std::cout << "closed form gamma" << (clf_pv_up -2.0*clf_pv + clf_pv_down) /ds/ds << std::endl;

	std::cout << "\n";

	Vol volat_up(volat);
	volat_up.Vol_up(0.01);
	MarketParam para_volup(0, spot, volat_up, r, q);
	BarrierOption Bar_cuo_vega(refprice, 365, cuo);
	Bar_cuo_vega.Calc(para_volup);

	std::vector<double> rs_vega = Bar_cuo_vega.GetResult();
	std::cout << "\npv(for vega)" << rs_vega[0] << std::endl;
	std::cout << "delta(for vega) " << rs_vega[1] << std::endl;
	std::cout << "gamma(for vega) " << rs_vega[2] << std::endl;
	std::cout << "spot(for vega) " << rs_vega[5] << std::endl;
	std::cout << "BS vol(for vega)=" << volat_up.getBSVol(1.0, callstrike) << std::endl;
	std::cout << "\n";

	std::cout << "vega(closed, Flatvol)=" << k_fmla_Barrier(0, 0, 1, 297.22, callstrike, refprice*1.205355, const_rf, const_q, const_vol + 0.01, 1.0, rebate) - k_fmla_Barrier(0, 0, 1, 297.22, callstrike, refprice*1.205355, const_rf, const_q, const_vol, 1.0, rebate) << std::endl;
	std::cout << "vega(for vega) " << rs_vega[0] - rs_bar[0] << std::endl;


}

void test_barrier_LV(double spot)
{
	double arr_rts[] = { 0.002739726,0.25,0.5,0.75,1,1.5,2,2.5,3,4,5,7,10,15,20 };
	double arr_r[] = { 1.54,1.64,1.72,1.77,1.8,1.85,1.88,1.90,1.92,1.92,1.92,1.92,1.92,1.92,1.92 };
	for (int i = 0; i<15; i++)
		arr_r[i] /= 100.0;

	double arr_qts[] = { 0.0191780821917808,0.038356164,0.057534247,0.084931507,0.104109589,0.123287671,0.142465753,0.167123288,0.252054795,0.334246575,0.419178082,0.504109589,0.580821918,0.665753425,0.747945205,0.832876712,0.915068493,1,1.084931507,1.167123288,1.252054795,1.334246575,1.419178082,1.504109589,1.583561644,1.668493151,1.750684932,1.835616438,1.917808219,	2.002739726	,2.087671233,2.169863014,2.254794521,2.336986301,2.421917808,2.506849315,2.583561644,2.668493151,2.750684932,2.835616438,2.917808219,3.002739726 };
	double arr_q[] = { 0.00000,0.00000,0.00000,2.57097, 2.09737,1.77112,1.53270, 1.30656 ,0.86631 ,5.16283, 4.11677,3.42318,3.34816,2.92103,2.60139,2.67302,2.43293,2.22630,2.26258, 2.10325,1.96057,3.00733,2.82806 ,2.66837, 2.53449,2.53675,2.41823 ,2.46233 ,2.35680 ,2.25685 ,2.27446 ,2.18831 ,2.10588 ,2.66917,2.57598,2.48871,2.41481,2.42319,2.35115 ,2.38170 ,2.31461 ,2.24914 };
	for (int i = 0; i<42; i++)
		arr_q[i] /= 100.0;

	//double spot=297.22;
	double vol_term[] = { 0.08493150,0.16712330,0.25205480,0.50410960,0.74794520,1.00000000,1.50410960,2.00273970,2.50684930,3.00273970 }; //10terms
	double vol_strike[] = { 178.332,193.193,208.054,222.915,237.776,252.637,267.498,282.359,297.22,312.081,326.942,341.803,356.664,371.525,386.386,401.247,416.108 };//17spot
	Vol volat(10, 17);
	double t0[] = { 0.3095,0.2907,0.2719,0.2528,0.2331,0.2136,0.1816,0.1388,0.1081,0.105,0.1296,0.1606,0.1795,0.1892,0.1978,0.2057,0.2129 };
	double t1[] = { 0.2807,0.2619,0.2431,0.2239,0.2042,0.1845,0.1586,0.1285,0.1095,0.1027,0.1076,0.1306,0.1518,0.1634,0.172,0.1798,0.1869 };
	double t2[] = { 0.2621,0.2448,0.2274,0.2098,0.1916,0.172,0.1505,0.128,0.1131,0.1076,0.1125,0.1264,0.1413,0.1517,0.16,0.1676,0.1745 };
	double t3[] = { 0.2376,0.2219,0.2061,0.1902,0.1741,0.1576,0.141,0.1261,0.1169,0.1161,0.1215,0.1292,0.1371,0.1447,0.1517,0.1583,0.1644 };
	double t4[] = { 0.2286,0.214,0.1997,0.1854,0.1712,0.1571,0.1437,0.1319,0.1238,0.1211,0.1231,0.128,0.1339,0.14,0.146,0.1517,0.1571 };
	double t5[] = { 0.221,0.2077,0.1946,0.1819,0.1694,0.1574,0.1462,0.1366,0.1295,0.1261,0.1261,0.1287,0.1327,0.1374,0.1422,0.1469,0.1516 };
	double t6[] = { 0.2063,0.1949,0.1841,0.1737,0.1639,0.1549,0.1469,0.1403,0.1355,0.1329,0.1322,0.1331,0.1352,0.1379,0.1409,0.1442,0.1475 };
	double t7[] = { 0.1993,0.1897,0.1806,0.1721,0.1642,0.157,0.1506,0.1453,0.1411,0.1383,0.1368,0.1364,0.1369,0.1381,0.1398,0.1418,0.144 };
	double t8[] = { 0.1927,0.1844,0.1768,0.1696,0.1631,0.1572,0.1521,0.1477,0.1443,0.1418,0.1402,0.1394,0.1393,0.1398,0.1407,0.1419,0.1434 };
	double t9[] = { 0.1892,0.182,0.1754,0.1692,0.1637,0.1586,0.1542,0.1505,0.1474,0.145,0.1432,0.1421,0.1415,0.1414,0.1417,0.1423,0.1431 };

	volat.set_vol_strike(vol_strike, 17);
	volat.set_vol_term(vol_term, 10);

	volat.set_volsurface_by_term(t0, 0, 17);
	volat.set_volsurface_by_term(t1, 1, 17);
	volat.set_volsurface_by_term(t2, 2, 17);
	volat.set_volsurface_by_term(t3, 3, 17);
	volat.set_volsurface_by_term(t4, 4, 17);
	volat.set_volsurface_by_term(t5, 5, 17);
	volat.set_volsurface_by_term(t6, 6, 17);
	volat.set_volsurface_by_term(t7, 7, 17);
	volat.set_volsurface_by_term(t8, 8, 17);
	volat.set_volsurface_by_term(t9, 9, 17);

	std::vector<double> v_rts(std::begin(arr_rts), std::end(arr_rts));
	std::vector<double> v_r(std::begin(arr_r), std::end(arr_r));
	std::vector<double> v_qts(std::begin(arr_qts), std::end(arr_qts));
	std::vector<double> v_q(std::begin(arr_q), std::end(arr_q));

	Rate r(v_r, v_rts);
	Rate q(v_q, v_qts);

	double refprice = 297.22;
	double rf_for_bs = r.getIntpRate(1.0);
	double div_for_bs = q.getIntpRate(1.0);
	double putstrike = 297.22*0.9;
	double callstrike = 297.22*1.0;
	double upbarrier = 297.22*1.2;
	double intpvol = volat.getInpVol(1.0, putstrike);
	double rebate = 0.0;

	double const_vol = volat.getBSVol(1.0, 297.22);
	double const_rf = r.getIntpRate(1.0);
	double const_q = q.getIntpRate(1.0);

	MarketParam para(0, spot, volat, r, q);

	PayoffBarCUO cuo(callstrike, upbarrier, rebate);

	BarrierOption Bar_cuo(refprice, 365, cuo);

	Bar_cuo.Calc(para);

	std::vector<double> rs_bar = Bar_cuo.GetResult();

	std::cout.precision(8);
	std::cout << std::fixed;

	std::cout << "\npv " << rs_bar[0] << std::endl;
	std::cout << "delta " << rs_bar[1] << std::endl;
	std::cout << "gamma " << rs_bar[2] << std::endl;
	std::cout << "spot " << rs_bar[5] << std::endl;
	std::cout << "atm vol at ref" << volat.getBSVol(1.0, refprice) << std::endl;

	const double ds = 297.22*0.01;
	double clf_pv = k_fmla_Barrier(0, 0, 1, 297.22, callstrike, refprice*1.205355, const_rf, const_q, const_vol, 1.0, rebate);
	double clf_pv_up = k_fmla_Barrier(0, 0, 1, 297.22 + ds, callstrike, refprice*1.205355, const_rf, const_q, const_vol, 1.0, rebate);
	double clf_pv_down = k_fmla_Barrier(0, 0, 1, 297.22 - ds, callstrike, refprice*1.205355, const_rf, const_q, const_vol, 1.0, rebate);

	std::cout << "closed form " << clf_pv << std::endl;
	std::cout << "closed form delta" << (clf_pv_up - clf_pv_down) / (ds*2.0) << std::endl;
	std::cout << "closed form gamma" << (clf_pv_up - 2.0*clf_pv + clf_pv_down) / ds / ds << std::endl;
	std::cout << "\n";

	Vol volat_up(volat);
	volat_up.Vol_up(0.01);
	MarketParam para_volup(0, spot, volat_up, r, q);
	BarrierOption Bar_cuo_vega(refprice, 365, cuo);
	Bar_cuo_vega.Calc(para_volup);

	std::vector<double> rs_vega = Bar_cuo_vega.GetResult();
	std::cout << "pv(for vega)" << rs_vega[0] << std::endl;
	std::cout << "delta(for vega) " << rs_vega[1] << std::endl;
	std::cout << "gamma(for vega) " << rs_vega[2] << std::endl;
	std::cout << "spot(for vega) " << rs_vega[5] << std::endl;
	std::cout << "BS vol(for vega)=" << volat_up.getBSVol(1.0, callstrike) << std::endl;
	std::cout << "\n";

	std::cout << "vega(closed, Flatvol)=" << k_fmla_Barrier(0, 0, 1, 297.22, callstrike, refprice*1.205355, const_rf, const_q, const_vol+0.01, 1.0, rebate)- k_fmla_Barrier(0, 0, 1, 297.22, callstrike, refprice*1.205355, const_rf, const_q, const_vol, 1.0, rebate) << std::endl;
	std::cout << "vega(for vega) " << rs_vega[0] - rs_bar[0] << std::endl;

}

void test_autocall_simple(double spot, int hitflag = 0, FvsS fvss = surface, CalcMode calcmode = calc1)
{
	double arr_rts[] = { 0.002739726,0.25,0.5,0.75,1,1.5,2,2.5,3,4,5,7,10,15,20 };
	//double arr_r[] = { 1.54,1.64,1.72,1.77,1.8,1.85,1.88,1.90,1.92,1.92,1.92,1.92,1.92,1.92,1.92 };
	double arr_r[] = { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };

	for (int i = 0; i<15; i++)
		arr_r[i] /= 100.0;

	double arr_qts[] = { 0.0191780821917808,0.038356164,0.057534247,0.084931507,0.104109589,0.123287671,0.142465753,0.167123288,0.252054795,0.334246575,0.419178082,0.504109589,0.580821918,0.665753425,0.747945205,0.832876712,0.915068493,1,1.084931507,1.167123288,1.252054795,1.334246575,1.419178082,1.504109589,1.583561644,1.668493151,1.750684932,1.835616438,1.917808219,	2.002739726	,2.087671233,2.169863014,2.254794521,2.336986301,2.421917808,2.506849315,2.583561644,2.668493151,2.750684932,2.835616438,2.917808219,3.002739726 };
	double arr_q[] = { 0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };
	for (int i = 0; i<42; i++)
		arr_q[i] /= 100.0;

	//double spot=297.22;
	double vol_term[] = { 0.08493150,0.16712330,0.25205480,0.50410960,0.74794520,1.00000000,1.50410960,2.00273970,2.50684930,3.00273970 }; //10terms
	double vol_strike[] = { 178.332,193.193,208.054,222.915,237.776,252.637,267.498,282.359,297.22,312.081,326.942,341.803,356.664,371.525,386.386,401.247,416.108 };//17spot
	Vol volat(10, 17);
	double t0[] = { 0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15 };
	double t1[] = { 0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15 };
	double t2[] = { 0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15 };
	double t3[] = { 0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15 };
	double t4[] = { 0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15 };
	double t5[] = { 0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15 };
	double t6[] = { 0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15 };
	double t7[] = { 0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15 };
	double t8[] = { 0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15 };
	double t9[] = { 0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15 };

	volat.set_vol_strike(vol_strike, 17);
	volat.set_vol_term(vol_term, 10);

	volat.set_volsurface_by_term(t0, 0, 17);
	volat.set_volsurface_by_term(t1, 1, 17);
	volat.set_volsurface_by_term(t2, 2, 17);
	volat.set_volsurface_by_term(t3, 3, 17);
	volat.set_volsurface_by_term(t4, 4, 17);
	volat.set_volsurface_by_term(t5, 5, 17);
	volat.set_volsurface_by_term(t6, 6, 17);
	volat.set_volsurface_by_term(t7, 7, 17);
	volat.set_volsurface_by_term(t8, 8, 17);
	volat.set_volsurface_by_term(t9, 9, 17);

	std::vector<double> v_rts(std::begin(arr_rts), std::end(arr_rts));
	std::vector<double> v_r(std::begin(arr_r), std::end(arr_r));
	std::vector<double> v_qts(std::begin(arr_qts), std::end(arr_qts));
	std::vector<double> v_q(std::begin(arr_q), std::end(arr_q));

	Rate r(v_r, v_rts);
	Rate q(v_q, v_qts);

	double refprice = 297.22;


	double rf_for_bs = r.getIntpRate(1.0);
	double div_for_bs = q.getIntpRate(1.0);
	double putstrike = 297.22*0.9;
	double callstrike = 297.22*1.0;
	double upbarrier = 297.22*1.2;
	double intpvol = volat.getInpVol(1.0, putstrike);
	double rebate = 0.0;

	double const_vol = volat.getBSVol(1.0, 297.22);
	double const_rf = r.getIntpRate(1.0);
	double const_q = q.getIntpRate(1.0);

	if (fvss == flat) {
		volat.set_const_vol(const_vol);
		r.set_const_rate(const_rf);
		q.set_const_rate(const_q);
	}

	MarketParam para(43340, spot, volat, r, q);

	signed int expiryDate = 44436;
	int nb_autocall = 6;
	signed int auto_date[7] = { -1,43524,43705,43889,44071,44255,44436 };
	double auto_strike[7] = { -1,297.22,	297.22,	282.359	,282.359,	267.498,	267.498 };
	double auto_coupon[7] = { -1, 0.0230,	0.0460,	0.0690,	0.0920,	0.1150,	0.1380 };
	double auto_ki_barrier = refprice*0.6;
	double auto_dummy_coupon = auto_coupon[6];

	double auto_put_strike;
	auto_put_strike = refprice*1.0; // if put_strike=0, notional protected

	PayoffAutocallStd autoPayoff(nb_autocall, auto_date, auto_strike, auto_coupon, auto_ki_barrier, auto_put_strike, auto_dummy_coupon, refprice);
	AutocallOption AutoKOSPI(refprice, expiryDate, autoPayoff, hitflag);

	AutoKOSPI.Calc(para);

	std::vector<double> rs_auto = AutoKOSPI.GetResult();

	std::cout.precision(8);
	std::cout << std::fixed;

	std::cout << "spot " << rs_auto[5] << std::endl;
	std::cout << "pv " << (hitflag ? "hitted  " : "not hit  ") << rs_auto[0] << std::endl;
	std::cout << "delta " << rs_auto[1] << std::endl;
	std::cout << "gamma " << rs_auto[2] << std::endl;

}

void test_autocall(double spot, int hitflag=0, FvsS fvss = surface, CalcMode calcmode=calc1)
{
	double arr_rts[] = { 0.002739726,0.25,0.5,0.75,1,1.5,2,2.5,3,4,5,7,10,15,20 };
	double arr_r[] = { 1.54,1.64,1.72,1.77,1.8,1.85,1.88,1.90,1.92,1.92,1.92,1.92,1.92,1.92,1.92 };
	for (int i = 0; i<15; i++)
		arr_r[i] /= 100.0;

	double arr_qts[] = { 0.0191780821917808,0.038356164,0.057534247,0.084931507,0.104109589,0.123287671,0.142465753,0.167123288,0.252054795,0.334246575,0.419178082,0.504109589,0.580821918,0.665753425,0.747945205,0.832876712,0.915068493,1,1.084931507,1.167123288,1.252054795,1.334246575,1.419178082,1.504109589,1.583561644,1.668493151,1.750684932,1.835616438,1.917808219,	2.002739726	,2.087671233,2.169863014,2.254794521,2.336986301,2.421917808,2.506849315,2.583561644,2.668493151,2.750684932,2.835616438,2.917808219,3.002739726 };
	double arr_q[] = {0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,4.5095,3.5958,2.9900,2.9722,2.5930,2.3094,2.4108,2.1943,2.0079,2.0613,1.9162,1.7862,2.8437,2.6742,2.5232,2.3966,2.4059,2.2935,2.3434,2.2429,2.1478,2.1699,2.0877,2.0090,2.5757,2.4858,2.4016,2.330293238,2.341357773,2.27176383,2.304693379,2.239772439,2.176421211};
	for (int i = 0; i<42; i++)
		arr_q[i] /= 100.0;

	//double spot=297.22;
	double vol_term[] = { 0.08493150,0.16712330,0.25205480,0.50410960,0.74794520,1.00000000,1.50410960,2.00273970,2.50684930,3.00273970 }; //10terms
	double vol_strike[] = { 178.332,193.193,208.054,222.915,237.776,252.637,267.498,282.359,297.22,312.081,326.942,341.803,356.664,371.525,386.386,401.247,416.108 };//17spot
	Vol volat(10, 17);
	double t0[] = { 0.3095,0.2907,0.2719,0.2528,0.2331,0.2136,0.1816,0.1388,0.1081,0.105,0.1296,0.1606,0.1795,0.1892,0.1978,0.2057,0.2129 };
	double t1[] = { 0.2807,0.2619,0.2431,0.2239,0.2042,0.1845,0.1586,0.1285,0.1095,0.1027,0.1076,0.1306,0.1518,0.1634,0.172,0.1798,0.1869 };
	double t2[] = { 0.2621,0.2448,0.2274,0.2098,0.1916,0.172,0.1505,0.128,0.1131,0.1076,0.1125,0.1264,0.1413,0.1517,0.16,0.1676,0.1745 };
	double t3[] = { 0.2376,0.2219,0.2061,0.1902,0.1741,0.1576,0.141,0.1261,0.1169,0.1161,0.1215,0.1292,0.1371,0.1447,0.1517,0.1583,0.1644 };
	double t4[] = { 0.2286,0.214,0.1997,0.1854,0.1712,0.1571,0.1437,0.1319,0.1238,0.1211,0.1231,0.128,0.1339,0.14,0.146,0.1517,0.1571 };
	double t5[] = { 0.221,0.2077,0.1946,0.1819,0.1694,0.1574,0.1462,0.1366,0.1295,0.1261,0.1261,0.1287,0.1327,0.1374,0.1422,0.1469,0.1516 };
	double t6[] = { 0.2063,0.1949,0.1841,0.1737,0.1639,0.1549,0.1469,0.1403,0.1355,0.1329,0.1322,0.1331,0.1352,0.1379,0.1409,0.1442,0.1475 };
	double t7[] = { 0.1993,0.1897,0.1806,0.1721,0.1642,0.157,0.1506,0.1453,0.1411,0.1383,0.1368,0.1364,0.1369,0.1381,0.1398,0.1418,0.144 };
	double t8[] = { 0.1927,0.1844,0.1768,0.1696,0.1631,0.1572,0.1521,0.1477,0.1443,0.1418,0.1402,0.1394,0.1393,0.1398,0.1407,0.1419,0.1434 };
	double t9[] = { 0.1892,0.182,0.1754,0.1692,0.1637,0.1586,0.1542,0.1505,0.1474,0.145,0.1432,0.1421,0.1415,0.1414,0.1417,0.1423,0.1431 };

	volat.set_vol_strike(vol_strike, 17);
	volat.set_vol_term(vol_term, 10);

	volat.set_volsurface_by_term(t0, 0, 17);
	volat.set_volsurface_by_term(t1, 1, 17);
	volat.set_volsurface_by_term(t2, 2, 17);
	volat.set_volsurface_by_term(t3, 3, 17);
	volat.set_volsurface_by_term(t4, 4, 17);
	volat.set_volsurface_by_term(t5, 5, 17);
	volat.set_volsurface_by_term(t6, 6, 17);
	volat.set_volsurface_by_term(t7, 7, 17);
	volat.set_volsurface_by_term(t8, 8, 17);
	volat.set_volsurface_by_term(t9, 9, 17);

	std::vector<double> v_rts(std::begin(arr_rts), std::end(arr_rts));
	std::vector<double> v_r(std::begin(arr_r), std::end(arr_r));
	std::vector<double> v_qts(std::begin(arr_qts), std::end(arr_qts));
	std::vector<double> v_q(std::begin(arr_q), std::end(arr_q));

	Rate r(v_r, v_rts);
	Rate q(v_q, v_qts);

	double refprice = 297.22;

	
	double rf_for_bs = r.getIntpRate(1.0);
	double div_for_bs = q.getIntpRate(1.0);
	double putstrike = 297.22*0.9;
	double callstrike = 297.22*1.0;
	double upbarrier = 297.22*1.2;
	double intpvol = volat.getInpVol(1.0, putstrike);
	double rebate = 0.0;

	double const_vol = volat.getBSVol(1.0, 297.22);
	double const_rf = r.getIntpRate(1.0);
	double const_q = q.getIntpRate(1.0);

	if (fvss == flat) {
		volat.set_const_vol(const_vol);
		r.set_const_rate(const_rf);
		q.set_const_rate(const_q);
	}

	MarketParam para(43340, spot, volat, r, q);

	signed int expiryDate = 44436;
	int nb_autocall = 6;
	signed int auto_date[7] = { -1,43524,43705,43889,44071,44255,44436};
	double auto_strike[7] = {-1,297.22,	297.22,	282.359	,282.359,	267.498,	267.498};
	double auto_coupon[7] = {-1, 0.0230,	0.0460,	0.0690,	0.0920,	0.1150,	0.1380};
	double auto_ki_barrier = refprice*0.6;
	double auto_dummy_coupon = auto_coupon[6];

	double auto_put_strike;
	auto_put_strike = refprice*1.0; // if put_strike=0, notional protected

	PayoffAutocallStd autoPayoff(nb_autocall, auto_date, auto_strike, auto_coupon, auto_ki_barrier, auto_put_strike, auto_dummy_coupon, refprice);
	AutocallOption AutoKOSPI(refprice, expiryDate, autoPayoff,hitflag);

	if (calcmode == calc1) {
		AutoKOSPI.Calc_old(para);
	}
	else if (calcmode == calc2) {
		AutoKOSPI.Calc(para);
	}

//	AutoKOSPI.Calc(para);

	std::vector<double> rs_auto = AutoKOSPI.GetResult();

	std::cout.precision(8);
	std::cout << std::fixed;

	std::cout << "spot " << rs_auto[5] << std::endl;
	std::cout << "pv "<< (hitflag ? "hitted  ":"not hit  ") << rs_auto[0] << std::endl;
	std::cout << "delta " << rs_auto[1] << std::endl;
	std::cout << "gamma " << rs_auto[2] << std::endl;

}


void test_autocall_div(double spot, int hitflag = 0, FvsS fvss = surface, CalcMode calcmode = calc1)
{
	double arr_rts[] = { 0.002739726,0.25,0.5,0.75,1,1.5,2,2.5,3,4,5,7,10,15,20 };
	double arr_r[] = { 1.54,1.64,1.72,1.77,1.8,1.85,1.88,1.90,1.92,1.92,1.92,1.92,1.92,1.92,1.92 };
	for (int i = 0; i<15; i++)
		arr_r[i] /= 100.0;

	double arr_qts[] = { 0.0191780821917808,0.038356164,0.057534247,0.084931507,0.104109589,0.123287671,0.142465753,0.167123288,0.252054795,0.334246575,0.419178082,0.504109589,0.580821918,0.665753425,0.747945205,0.832876712,0.915068493,1,1.084931507,1.167123288,1.252054795,1.334246575,1.419178082,1.504109589,1.583561644,1.668493151,1.750684932,1.835616438,1.917808219,	2.002739726	,2.087671233,2.169863014,2.254794521,2.336986301,2.421917808,2.506849315,2.583561644,2.668493151,2.750684932,2.835616438,2.917808219,3.002739726 };
	double arr_q[] = { 0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,4.5095,3.5958,2.9900,2.9722,2.5930,2.3094,2.4108,2.1943,2.0079,2.0613,1.9162,1.7862,2.8437,2.6742,2.5232,2.3966,2.4059,2.2935,2.3434,2.2429,2.1478,2.1699,2.0877,2.0090,2.5757,2.4858,2.4016,2.330293238,2.341357773,2.27176383,2.304693379,2.239772439,2.176421211 };
	for (int i = 0; i<42; i++)
		arr_q[i] /= 100.0;

	//double spot=297.22;
	double vol_term[] = { 0.08493150,0.16712330,0.25205480,0.50410960,0.74794520,1.00000000,1.50410960,2.00273970,2.50684930,3.00273970 }; //10terms
	double vol_strike[] = { 178.332,193.193,208.054,222.915,237.776,252.637,267.498,282.359,297.22,312.081,326.942,341.803,356.664,371.525,386.386,401.247,416.108 };//17spot
	Vol volat(10, 17);
	double t0[] = { 0.3095,0.2907,0.2719,0.2528,0.2331,0.2136,0.1816,0.1388,0.1081,0.105,0.1296,0.1606,0.1795,0.1892,0.1978,0.2057,0.2129 };
	double t1[] = { 0.2807,0.2619,0.2431,0.2239,0.2042,0.1845,0.1586,0.1285,0.1095,0.1027,0.1076,0.1306,0.1518,0.1634,0.172,0.1798,0.1869 };
	double t2[] = { 0.2621,0.2448,0.2274,0.2098,0.1916,0.172,0.1505,0.128,0.1131,0.1076,0.1125,0.1264,0.1413,0.1517,0.16,0.1676,0.1745 };
	double t3[] = { 0.2376,0.2219,0.2061,0.1902,0.1741,0.1576,0.141,0.1261,0.1169,0.1161,0.1215,0.1292,0.1371,0.1447,0.1517,0.1583,0.1644 };
	double t4[] = { 0.2286,0.214,0.1997,0.1854,0.1712,0.1571,0.1437,0.1319,0.1238,0.1211,0.1231,0.128,0.1339,0.14,0.146,0.1517,0.1571 };
	double t5[] = { 0.221,0.2077,0.1946,0.1819,0.1694,0.1574,0.1462,0.1366,0.1295,0.1261,0.1261,0.1287,0.1327,0.1374,0.1422,0.1469,0.1516 };
	double t6[] = { 0.2063,0.1949,0.1841,0.1737,0.1639,0.1549,0.1469,0.1403,0.1355,0.1329,0.1322,0.1331,0.1352,0.1379,0.1409,0.1442,0.1475 };
	double t7[] = { 0.1993,0.1897,0.1806,0.1721,0.1642,0.157,0.1506,0.1453,0.1411,0.1383,0.1368,0.1364,0.1369,0.1381,0.1398,0.1418,0.144 };
	double t8[] = { 0.1927,0.1844,0.1768,0.1696,0.1631,0.1572,0.1521,0.1477,0.1443,0.1418,0.1402,0.1394,0.1393,0.1398,0.1407,0.1419,0.1434 };
	double t9[] = { 0.1892,0.182,0.1754,0.1692,0.1637,0.1586,0.1542,0.1505,0.1474,0.145,0.1432,0.1421,0.1415,0.1414,0.1417,0.1423,0.1431 };

	volat.set_vol_strike(vol_strike, 17);
	volat.set_vol_term(vol_term, 10);

	volat.set_volsurface_by_term(t0, 0, 17);
	volat.set_volsurface_by_term(t1, 1, 17);
	volat.set_volsurface_by_term(t2, 2, 17);
	volat.set_volsurface_by_term(t3, 3, 17);
	volat.set_volsurface_by_term(t4, 4, 17);
	volat.set_volsurface_by_term(t5, 5, 17);
	volat.set_volsurface_by_term(t6, 6, 17);
	volat.set_volsurface_by_term(t7, 7, 17);
	volat.set_volsurface_by_term(t8, 8, 17);
	volat.set_volsurface_by_term(t9, 9, 17);

	std::vector<double> v_rts(std::begin(arr_rts), std::end(arr_rts));
	std::vector<double> v_r(std::begin(arr_r), std::end(arr_r));
	std::vector<double> v_qts(std::begin(arr_qts), std::end(arr_qts));
	std::vector<double> v_q(std::begin(arr_q), std::end(arr_q));

	Rate r(v_r, v_rts);
	Rate q(v_q, v_qts);

	double refprice = 297.22;


	double rf_for_bs = r.getIntpRate(1.0);
	double div_for_bs = q.getIntpRate(1.0);
	double putstrike = 297.22*0.9;
	double callstrike = 297.22*1.0;
	double upbarrier = 297.22*1.2;
	double intpvol = volat.getInpVol(1.0, putstrike);
	double rebate = 0.0;

	double const_vol = volat.getBSVol(1.0, 297.22);
	double const_rf = r.getIntpRate(1.0);
	double const_q = q.getIntpRate(1.0);

	if (fvss == flat) {
		volat.set_const_vol(const_vol);
		r.set_const_rate(const_rf);
		q.set_const_rate(const_q);
	}

	MarketParam para(43340, spot, volat, r, q);

	signed int expiryDate = 44436;
	int nb_autocall = 6;
	signed int auto_date[7] = { -1,43524,43705,43889,44071,44255,44436 };
	double auto_strike[7] = { -1,297.22,	297.22,	282.359	,282.359,	267.498,	267.498 };
	double auto_coupon[7] = { -1, 0.0230,	0.0460,	0.0690,	0.0920,	0.1150,	0.1380 };
	double auto_ki_barrier = refprice*0.6;
	double auto_dummy_coupon = auto_coupon[6];

	double auto_put_strike;
	auto_put_strike = refprice*1.0; // if put_strike=0, notional protected

	PayoffAutocallStd autoPayoff(nb_autocall, auto_date, auto_strike, auto_coupon, auto_ki_barrier, auto_put_strike, auto_dummy_coupon, refprice);
	AutocallOption AutoKOSPI(refprice, expiryDate, autoPayoff, hitflag);

	AutoKOSPI.Calc(para);

	std::vector<double> rs_auto = AutoKOSPI.GetResult();

	std::cout.precision(8);
	std::cout << std::fixed;

	std::cout << "spot " << rs_auto[5] << std::endl;
	std::cout << "pv " << (hitflag ? "hitted  " : "not hit  ") << rs_auto[0] << std::endl;
	std::cout << "delta " << rs_auto[1] << std::endl;
	std::cout << "gamma " << rs_auto[2] << std::endl;

}


void test_autocall_mc(double spot, int hitflag = 0, long nMC=30000, FvsS fvss=surface)
{
	double arr_rts[] = { 0.002739726,0.25,0.5,0.75,1,1.5,2,2.5,3,4,5,7,10,15,20 };
	double arr_r[] = { 1.54,1.64,1.72,1.77,1.8,1.85,1.88,1.90,1.92,1.92,1.92,1.92,1.92,1.92,1.92 };
	for (int i = 0; i<15; i++)
		arr_r[i] /= 100.0;

	double arr_qts[] = { 0.0191780821917808,0.038356164,0.057534247,0.084931507,0.104109589,0.123287671,0.142465753,0.167123288,0.252054795,0.334246575,0.419178082,0.504109589,0.580821918,0.665753425,0.747945205,0.832876712,0.915068493,1,1.084931507,1.167123288,1.252054795,1.334246575,1.419178082,1.504109589,1.583561644,1.668493151,1.750684932,1.835616438,1.917808219,	2.002739726	,2.087671233,2.169863014,2.254794521,2.336986301,2.421917808,2.506849315,2.583561644,2.668493151,2.750684932,2.835616438,2.917808219,3.002739726 };
	double arr_q[] = { 0.00000,0.00000,0.00000,2.57097, 2.09737,1.77112,1.53270, 1.30656 ,0.86631 ,5.16283, 4.11677,3.42318,3.34816,2.92103,2.60139,2.67302,2.43293,2.22630,2.26258, 2.10325,1.96057,3.00733,2.82806 ,2.66837, 2.53449,2.53675,2.41823 ,2.46233 ,2.35680 ,2.25685 ,2.27446 ,2.18831 ,2.10588 ,2.66917,2.57598,2.48871,2.41481,2.42319,2.35115 ,2.38170 ,2.31461 ,2.24914 };
	for (int i = 0; i<42; i++)
		arr_q[i] /= 100.0;

	//double spot=297.22;
	double vol_term[] = { 0.08493150,0.16712330,0.25205480,0.50410960,0.74794520,1.00000000,1.50410960,2.00273970,2.50684930,3.00273970 }; //10terms
	double vol_strike[] = { 178.332,193.193,208.054,222.915,237.776,252.637,267.498,282.359,297.22,312.081,326.942,341.803,356.664,371.525,386.386,401.247,416.108 };//17spot
	Vol volat(10, 17);
	double t0[] = { 0.3095,0.2907,0.2719,0.2528,0.2331,0.2136,0.1816,0.1388,0.1081,0.105,0.1296,0.1606,0.1795,0.1892,0.1978,0.2057,0.2129 };
	double t1[] = { 0.2807,0.2619,0.2431,0.2239,0.2042,0.1845,0.1586,0.1285,0.1095,0.1027,0.1076,0.1306,0.1518,0.1634,0.172,0.1798,0.1869 };
	double t2[] = { 0.2621,0.2448,0.2274,0.2098,0.1916,0.172,0.1505,0.128,0.1131,0.1076,0.1125,0.1264,0.1413,0.1517,0.16,0.1676,0.1745 };
	double t3[] = { 0.2376,0.2219,0.2061,0.1902,0.1741,0.1576,0.141,0.1261,0.1169,0.1161,0.1215,0.1292,0.1371,0.1447,0.1517,0.1583,0.1644 };
	double t4[] = { 0.2286,0.214,0.1997,0.1854,0.1712,0.1571,0.1437,0.1319,0.1238,0.1211,0.1231,0.128,0.1339,0.14,0.146,0.1517,0.1571 };
	double t5[] = { 0.221,0.2077,0.1946,0.1819,0.1694,0.1574,0.1462,0.1366,0.1295,0.1261,0.1261,0.1287,0.1327,0.1374,0.1422,0.1469,0.1516 };
	double t6[] = { 0.2063,0.1949,0.1841,0.1737,0.1639,0.1549,0.1469,0.1403,0.1355,0.1329,0.1322,0.1331,0.1352,0.1379,0.1409,0.1442,0.1475 };
	double t7[] = { 0.1993,0.1897,0.1806,0.1721,0.1642,0.157,0.1506,0.1453,0.1411,0.1383,0.1368,0.1364,0.1369,0.1381,0.1398,0.1418,0.144 };
	double t8[] = { 0.1927,0.1844,0.1768,0.1696,0.1631,0.1572,0.1521,0.1477,0.1443,0.1418,0.1402,0.1394,0.1393,0.1398,0.1407,0.1419,0.1434 };
	double t9[] = { 0.1892,0.182,0.1754,0.1692,0.1637,0.1586,0.1542,0.1505,0.1474,0.145,0.1432,0.1421,0.1415,0.1414,0.1417,0.1423,0.1431 };

	volat.set_vol_strike(vol_strike, 17);
	volat.set_vol_term(vol_term, 10);

	volat.set_volsurface_by_term(t0, 0, 17);
	volat.set_volsurface_by_term(t1, 1, 17);
	volat.set_volsurface_by_term(t2, 2, 17);
	volat.set_volsurface_by_term(t3, 3, 17);
	volat.set_volsurface_by_term(t4, 4, 17);
	volat.set_volsurface_by_term(t5, 5, 17);
	volat.set_volsurface_by_term(t6, 6, 17);
	volat.set_volsurface_by_term(t7, 7, 17);
	volat.set_volsurface_by_term(t8, 8, 17);
	volat.set_volsurface_by_term(t9, 9, 17);

	std::vector<double> v_rts(std::begin(arr_rts), std::end(arr_rts));
	std::vector<double> v_r(std::begin(arr_r), std::end(arr_r));
	std::vector<double> v_qts(std::begin(arr_qts), std::end(arr_qts));
	std::vector<double> v_q(std::begin(arr_q), std::end(arr_q));

	Rate r(v_r, v_rts);
	Rate q(v_q, v_qts);

	double refprice = 297.22;
	double rf_for_bs = r.getIntpRate(1.0);
	double div_for_bs = q.getIntpRate(1.0);
	double putstrike = 297.22*0.9;
	double callstrike = 297.22*1.0;
	double upbarrier = 297.22*1.2;
	double intpvol = volat.getInpVol(1.0, putstrike);
	double rebate = 0.0;

	double const_vol = volat.getBSVol(1.0, 297.22);
	double const_rf = r.getIntpRate(1.0);
	double const_q = q.getIntpRate(1.0);

	if (fvss == flat) {
		volat.set_const_vol(const_vol);
		r.set_const_rate(const_rf);
		q.set_const_rate(const_q);
	}

	MarketParam para(43340, spot, volat, r, q);
	signed int exd = 44436;
	int nb_autocall = 6;
	signed int auto_date[7] = { -1,43524,43705,43889,44071,44255,44436 };
	double auto_strike[7] = { -1,297.22,	297.22,	282.359	,282.359,	267.498,	267.498 };
	double auto_coupon[7] = { -1, 0.0230,	0.0460,	0.0690,	0.0920,	0.1150,	0.1380 };
	double auto_ki_barrier = refprice*0.6;
	double auto_dummy_coupon = auto_coupon[6];


	double auto_put_strike;
	auto_put_strike = refprice; // if put_strike=0, notional protected

	PayoffAutocallStd autoPayoff(nb_autocall, auto_date, auto_strike, auto_coupon, auto_ki_barrier, auto_put_strike, auto_dummy_coupon, refprice);
	AutocallOption AutoKOSPI(refprice, exd, autoPayoff, hitflag);
	AutoKOSPI.CalcMC(para, nMC);
	std::vector<double> rs_auto = AutoKOSPI.GetResult();

	std::cout.precision(8);
	std::cout << std::fixed;

	std::cout << "\npv(MC) " << (hitflag ? "hitted  " : "not hit  ") << rs_auto[10] << std::endl;

	std::cout << "atm vol at ref " << volat.getBSVol(1.0, refprice) << std::endl;


}


void test_autocall_mc2(double spot, int hitflag = 0, long nMC = 30000, FvsS fvss = surface)
{
	double arr_rts[] = { 0.002739726,0.25,0.5,0.75,1,1.5,2,2.5,3,4,5,7,10,15,20 };
	double arr_r[] = { 1.54,1.64,1.72,1.77,1.8,1.85,1.88,1.90,1.92,1.92,1.92,1.92,1.92,1.92,1.92 };
	for (int i = 0; i<15; i++)
		arr_r[i] /= 100.0;

	double arr_qts[] = { 0.0191780821917808,0.038356164,0.057534247,0.084931507,0.104109589,0.123287671,0.142465753,0.167123288,0.252054795,0.334246575,0.419178082,0.504109589,0.580821918,0.665753425,0.747945205,0.832876712,0.915068493,1,1.084931507,1.167123288,1.252054795,1.334246575,1.419178082,1.504109589,1.583561644,1.668493151,1.750684932,1.835616438,1.917808219,	2.002739726	,2.087671233,2.169863014,2.254794521,2.336986301,2.421917808,2.506849315,2.583561644,2.668493151,2.750684932,2.835616438,2.917808219,3.002739726 };
	double arr_q[] = { 0.00000,0.00000,0.00000,2.57097, 2.09737,1.77112,1.53270, 1.30656 ,0.86631 ,5.16283, 4.11677,3.42318,3.34816,2.92103,2.60139,2.67302,2.43293,2.22630,2.26258, 2.10325,1.96057,3.00733,2.82806 ,2.66837, 2.53449,2.53675,2.41823 ,2.46233 ,2.35680 ,2.25685 ,2.27446 ,2.18831 ,2.10588 ,2.66917,2.57598,2.48871,2.41481,2.42319,2.35115 ,2.38170 ,2.31461 ,2.24914 };
	for (int i = 0; i<42; i++)
		arr_q[i] /= 100.0;

	//double spot=297.22;
	double vol_term[] = { 0.08493150,0.16712330,0.25205480,0.50410960,0.74794520,1.00000000,1.50410960,2.00273970,2.50684930,3.00273970 }; //10terms
	double vol_strike[] = { 178.332,193.193,208.054,222.915,237.776,252.637,267.498,282.359,297.22,312.081,326.942,341.803,356.664,371.525,386.386,401.247,416.108 };//17spot
	Vol volat(10, 17);
	double t0[] = { 0.3095,0.2907,0.2719,0.2528,0.2331,0.2136,0.1816,0.1388,0.1081,0.105,0.1296,0.1606,0.1795,0.1892,0.1978,0.2057,0.2129 };
	double t1[] = { 0.2807,0.2619,0.2431,0.2239,0.2042,0.1845,0.1586,0.1285,0.1095,0.1027,0.1076,0.1306,0.1518,0.1634,0.172,0.1798,0.1869 };
	double t2[] = { 0.2621,0.2448,0.2274,0.2098,0.1916,0.172,0.1505,0.128,0.1131,0.1076,0.1125,0.1264,0.1413,0.1517,0.16,0.1676,0.1745 };
	double t3[] = { 0.2376,0.2219,0.2061,0.1902,0.1741,0.1576,0.141,0.1261,0.1169,0.1161,0.1215,0.1292,0.1371,0.1447,0.1517,0.1583,0.1644 };
	double t4[] = { 0.2286,0.214,0.1997,0.1854,0.1712,0.1571,0.1437,0.1319,0.1238,0.1211,0.1231,0.128,0.1339,0.14,0.146,0.1517,0.1571 };
	double t5[] = { 0.221,0.2077,0.1946,0.1819,0.1694,0.1574,0.1462,0.1366,0.1295,0.1261,0.1261,0.1287,0.1327,0.1374,0.1422,0.1469,0.1516 };
	double t6[] = { 0.2063,0.1949,0.1841,0.1737,0.1639,0.1549,0.1469,0.1403,0.1355,0.1329,0.1322,0.1331,0.1352,0.1379,0.1409,0.1442,0.1475 };
	double t7[] = { 0.1993,0.1897,0.1806,0.1721,0.1642,0.157,0.1506,0.1453,0.1411,0.1383,0.1368,0.1364,0.1369,0.1381,0.1398,0.1418,0.144 };
	double t8[] = { 0.1927,0.1844,0.1768,0.1696,0.1631,0.1572,0.1521,0.1477,0.1443,0.1418,0.1402,0.1394,0.1393,0.1398,0.1407,0.1419,0.1434 };
	double t9[] = { 0.1892,0.182,0.1754,0.1692,0.1637,0.1586,0.1542,0.1505,0.1474,0.145,0.1432,0.1421,0.1415,0.1414,0.1417,0.1423,0.1431 };

	volat.set_vol_strike(vol_strike, 17);
	volat.set_vol_term(vol_term, 10);

	volat.set_volsurface_by_term(t0, 0, 17);
	volat.set_volsurface_by_term(t1, 1, 17);
	volat.set_volsurface_by_term(t2, 2, 17);
	volat.set_volsurface_by_term(t3, 3, 17);
	volat.set_volsurface_by_term(t4, 4, 17);
	volat.set_volsurface_by_term(t5, 5, 17);
	volat.set_volsurface_by_term(t6, 6, 17);
	volat.set_volsurface_by_term(t7, 7, 17);
	volat.set_volsurface_by_term(t8, 8, 17);
	volat.set_volsurface_by_term(t9, 9, 17);

	std::vector<double> v_rts(std::begin(arr_rts), std::end(arr_rts));
	std::vector<double> v_r(std::begin(arr_r), std::end(arr_r));
	std::vector<double> v_qts(std::begin(arr_qts), std::end(arr_qts));
	std::vector<double> v_q(std::begin(arr_q), std::end(arr_q));

	Rate r(v_r, v_rts);
	Rate q(v_q, v_qts);

	double refprice = 297.22;
	double rf_for_bs = r.getIntpRate(1.0);
	double div_for_bs = q.getIntpRate(1.0);
	double putstrike = 297.22*0.9;
	double callstrike = 297.22*1.0;
	double upbarrier = 297.22*1.2;
	double intpvol = volat.getInpVol(1.0, putstrike);
	double rebate = 0.0;

	double const_vol = volat.getBSVol(1.0, 297.22);
	double const_rf = r.getIntpRate(1.0);
	double const_q = q.getIntpRate(1.0);

	if (fvss == flat) {
		volat.set_const_vol(const_vol);
		r.set_const_rate(const_rf);
		q.set_const_rate(const_q);
	}
	MarketParam para(43340, spot, volat, r, q);
	
	signed int exd = 44436;
	int nb_autocall = 6;
	signed int auto_date[7] = { -1,43524,43705,43889,44071,44255,44436 };
	double auto_strike[7] = { -1,297.22,297.22,282.359,282.359,267.498,267.498};
	double auto_coupon[7] = { -1, 0.0230,0.0460,0.0690,0.0920,0.1150,0.1380};
	double auto_ki_barrier = refprice*0.6;
	double auto_dummy_coupon = auto_coupon[6];

	double auto_put_strike;
	auto_put_strike = refprice; // if put_strike=0, notional protected

	PayoffAutocallStd autoPayoff(nb_autocall, auto_date, auto_strike, auto_coupon, auto_ki_barrier, auto_put_strike, auto_dummy_coupon, refprice);
	AutocallOption AutoKOSPI(refprice, exd, autoPayoff, hitflag);
	AutoKOSPI.CalcMC2(para, nMC);
	std::vector<double> rs_auto = AutoKOSPI.GetResult();

	std::cout.precision(8);
	std::cout << std::fixed;

	std::cout << "\npv(MC2) " << (hitflag ? "hitted  " : "not hit  ") << rs_auto[10] << std::endl;
	//std::cout << "delta " << rs_auto[1] << std::endl;
	//std::cout << "gamma " << rs_auto[2] << std::endl;
	std::cout << "spot " << rs_auto[5] << std::endl;
	std::cout << "atm vol at ref " << volat.getBSVol(1.0, refprice) << std::endl;

	//const double ds = 297.22*0.01;

	//Vol volat_up(volat);
	//volat_up.Vol_up(0.01);
	//MarketParam para_volup(0, spot, volat_up, r, q);
	//AutocallOption AutoKOSPI_vega(refprice, exd, autoPayoff, hitflag);
	//AutoKOSPI_vega.CalcMC2(para_volup, nMC);


	//std::vector<double> rs_vega = AutoKOSPI_vega.GetResult();
	//std::cout << "\npv(for vega)  " << (hitflag ? "hitted  " : "not hit  ") << rs_vega[10] << std::endl;
	////std::cout << "delta(for vega) " << rs_vega[1] << std::endl;
	////std::cout << "gamma(for vega) " << rs_vega[2] << std::endl;
	////std::cout << "spot(for vega) " << rs_vega[5] << std::endl;
	//std::cout << "BS vol(for vega)=" << volat_up.getBSVol(1.0, callstrike) << std::endl;
	////std::cout << "\n";

	//std::cout << "vega(for vega) " << rs_vega[10] - rs_auto[10] << std::endl;
}


void test_autocall_mc2_simple(double spot, int hitflag = 0, long nMC = 30000, FvsS fvss = surface)
{
	double arr_rts[] = { 0.002739726,0.25,0.5,0.75,1,1.5,2,2.5,3,4,5,7,10,15,20 };
	//double arr_r[] = { 1.54,1.64,1.72,1.77,1.8,1.85,1.88,1.90,1.92,1.92,1.92,1.92,1.92,1.92,1.92 };
	double arr_r[] = { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };

	for (int i = 0; i<15; i++)
		arr_r[i] /= 100.0;

	double arr_qts[] = { 0.0191780821917808,0.038356164,0.057534247,0.084931507,0.104109589,0.123287671,0.142465753,0.167123288,0.252054795,0.334246575,0.419178082,0.504109589,0.580821918,0.665753425,0.747945205,0.832876712,0.915068493,1,1.084931507,1.167123288,1.252054795,1.334246575,1.419178082,1.504109589,1.583561644,1.668493151,1.750684932,1.835616438,1.917808219,	2.002739726	,2.087671233,2.169863014,2.254794521,2.336986301,2.421917808,2.506849315,2.583561644,2.668493151,2.750684932,2.835616438,2.917808219,3.002739726 };
	double arr_q[] = { 0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };
	for (int i = 0; i<42; i++)
		arr_q[i] /= 100.0;

	//double spot=297.22;
	double vol_term[] = { 0.08493150,0.16712330,0.25205480,0.50410960,0.74794520,1.00000000,1.50410960,2.00273970,2.50684930,3.00273970 }; //10terms
	double vol_strike[] = { 178.332,193.193,208.054,222.915,237.776,252.637,267.498,282.359,297.22,312.081,326.942,341.803,356.664,371.525,386.386,401.247,416.108 };//17spot
	Vol volat(10, 17);
	double t0[] = { 0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15 };
	double t1[] = { 0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15 };
	double t2[] = { 0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15 };
	double t3[] = { 0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15 };
	double t4[] = { 0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15 };
	double t5[] = { 0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15 };
	double t6[] = { 0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15 };
	double t7[] = { 0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15 };
	double t8[] = { 0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15 };
	double t9[] = { 0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15,0.15 };


	volat.set_vol_strike(vol_strike, 17);
	volat.set_vol_term(vol_term, 10);

	volat.set_volsurface_by_term(t0, 0, 17);
	volat.set_volsurface_by_term(t1, 1, 17);
	volat.set_volsurface_by_term(t2, 2, 17);
	volat.set_volsurface_by_term(t3, 3, 17);
	volat.set_volsurface_by_term(t4, 4, 17);
	volat.set_volsurface_by_term(t5, 5, 17);
	volat.set_volsurface_by_term(t6, 6, 17);
	volat.set_volsurface_by_term(t7, 7, 17);
	volat.set_volsurface_by_term(t8, 8, 17);
	volat.set_volsurface_by_term(t9, 9, 17);

	std::vector<double> v_rts(std::begin(arr_rts), std::end(arr_rts));
	std::vector<double> v_r(std::begin(arr_r), std::end(arr_r));
	std::vector<double> v_qts(std::begin(arr_qts), std::end(arr_qts));
	std::vector<double> v_q(std::begin(arr_q), std::end(arr_q));

	Rate r(v_r, v_rts);
	Rate q(v_q, v_qts);

	double refprice = 297.22;
	double rf_for_bs = r.getIntpRate(1.0);
	double div_for_bs = q.getIntpRate(1.0);
	double putstrike = 297.22*0.9;
	double callstrike = 297.22*1.0;
	double upbarrier = 297.22*1.2;
	double intpvol = volat.getInpVol(1.0, putstrike);
	double rebate = 0.0;

	double const_vol = volat.getBSVol(1.0, 297.22);
	double const_rf = r.getIntpRate(1.0);
	double const_q = q.getIntpRate(1.0);

	if (fvss == flat) {
		volat.set_const_vol(const_vol);
		r.set_const_rate(const_rf);
		q.set_const_rate(const_q);
	}
	MarketParam para(43340, spot, volat, r, q);

	signed int exd = 44436;
	int nb_autocall = 6;
	signed int auto_date[7] = { -1,43524,43705,43889,44071,44255,44436 };
	double auto_strike[7] = { -1,297.22,297.22,282.359,282.359,267.498,267.498 };
	double auto_coupon[7] = { -1, 0.0230,0.0460,0.0690,0.0920,0.1150,0.1380 };
	double auto_ki_barrier = refprice*0.6;
	double auto_dummy_coupon = auto_coupon[6];

	double auto_put_strike;
	auto_put_strike = refprice; // if put_strike=0, notional protected

	PayoffAutocallStd autoPayoff(nb_autocall, auto_date, auto_strike, auto_coupon, auto_ki_barrier, auto_put_strike, auto_dummy_coupon, refprice);
	AutocallOption AutoKOSPI(refprice, exd, autoPayoff, hitflag);
	AutoKOSPI.CalcMC2(para, nMC);
	std::vector<double> rs_auto = AutoKOSPI.GetResult();

	std::cout.precision(8);
	std::cout << std::fixed;

	std::cout << "\npv(MC2) " << (hitflag ? "hitted  " : "not hit  ") << rs_auto[10] << std::endl;
	//std::cout << "delta " << rs_auto[1] << std::endl;
	//std::cout << "gamma " << rs_auto[2] << std::endl;
	std::cout << "spot " << rs_auto[5] << std::endl;
	std::cout << "atm vol at ref " << volat.getBSVol(1.0, refprice) << std::endl;

	//const double ds = 297.22*0.01;

	//Vol volat_up(volat);
	//volat_up.Vol_up(0.01);
	//MarketParam para_volup(0, spot, volat_up, r, q);
	//AutocallOption AutoKOSPI_vega(refprice, exd, autoPayoff, hitflag);
	//AutoKOSPI_vega.CalcMC2(para_volup, nMC);


	//std::vector<double> rs_vega = AutoKOSPI_vega.GetResult();
	//std::cout << "\npv(for vega)  " << (hitflag ? "hitted  " : "not hit  ") << rs_vega[10] << std::endl;
	////std::cout << "delta(for vega) " << rs_vega[1] << std::endl;
	////std::cout << "gamma(for vega) " << rs_vega[2] << std::endl;
	////std::cout << "spot(for vega) " << rs_vega[5] << std::endl;
	//std::cout << "BS vol(for vega)=" << volat_up.getBSVol(1.0, callstrike) << std::endl;
	////std::cout << "\n";

	//std::cout << "vega(for vega) " << rs_vega[10] - rs_auto[10] << std::endl;
}
void test_dividend()
{
	vector<signed int> exd = { 1,2,3,4,5,6,7,8,9,10 };
	vector<double> amt = { 10,20,30,40,50,60,70,80,90,100 };
	Dividend di(exd, amt);
	//cout << di.getLumpsum(3, 8);

}

void test_european_discrete_localvol(double spot)
{

	double arr_rts[] = { 0.002739726,0.25,0.5,0.75,1,1.5,2,2.5,3,4,5,7,10,15,20 };
	double arr_r[] = { 1.54,1.64,1.72,1.77,1.8,1.85,1.88,1.90,1.92,1.92,1.92,1.92,1.92,1.92,1.92 };
	for (int i = 0; i<15; i++)
		arr_r[i] /= 100.0;

	double arr_qts[] = { 0.0191780821917808,0.038356164,0.057534247,0.084931507,0.104109589,0.123287671,0.142465753,0.167123288,0.252054795,0.334246575,0.419178082,0.504109589,0.580821918,0.665753425,0.747945205,0.832876712,0.915068493,1,1.084931507,1.167123288,1.252054795,1.334246575,1.419178082,1.504109589,1.583561644,1.668493151,1.750684932,1.835616438,1.917808219,	2.002739726	,2.087671233,2.169863014,2.254794521,2.336986301,2.421917808,2.506849315,2.583561644,2.668493151,2.750684932,2.835616438,2.917808219,3.002739726 };
	double arr_q[] = { 0.00000 ,	0.00000 ,	0.00000 ,	2.63436 	,2.14908 ,	1.81478 ,	1.57048 ,	1.33877 ,	0.88766 	,5.31382 	,4.23716 	,3.52329 ,	3.05795 	,2.99785 ,	2.66841 ,	2.39631 	,2.48698 	,2.27576 ,	2.30383,	2.14159 ,	1.99631 ,	1.88696 ,	2.91222 ,	2.74778 	,2.60992 ,	2.60935 	,2.48684 ,	2.37178 ,	2.42136 ,	2.31867 ,	2.22434 ,	2.24367 	,2.15915 	,2.09099 ,	2.70142 ,	2.60990 ,	2.53241 	,2.53452 ,	2.45878 ,	2.38514 ,	2.41735 ,	2.34898};
	for (int i = 0; i<42; i++)
		arr_q[i] /= 100.0;

	//double spot=297.22;
	double vol_term[] = { 0.08493150,0.16712330,0.25205480,0.50410960,0.74794520,1.00000000,1.50410960,2.00273970,2.50684930,3.00273970 }; //10terms
	double vol_strike[] = { 178.332,193.193,208.054,222.915,237.776,252.637,267.498,282.359,297.22,312.081,326.942,341.803,356.664,371.525,386.386,401.247,416.108 };//17spot
	Vol volat(10, 17);
	double t0[] = { 0.3095,0.2907,0.2719,0.2528,0.2331,0.2136,0.1816,0.1388,0.1081,0.105,0.1296,0.1606,0.1795,0.1892,0.1978,0.2057,0.2129 };
	double t1[] = { 0.2807,0.2619,0.2431,0.2239,0.2042,0.1845,0.1586,0.1285,0.1095,0.1027,0.1076,0.1306,0.1518,0.1634,0.172,0.1798,0.1869 };
	double t2[] = { 0.2621,0.2448,0.2274,0.2098,0.1916,0.172,0.1505,0.128,0.1131,0.1076,0.1125,0.1264,0.1413,0.1517,0.16,0.1676,0.1745 };
	double t3[] = { 0.2376,0.2219,0.2061,0.1902,0.1741,0.1576,0.141,0.1261,0.1169,0.1161,0.1215,0.1292,0.1371,0.1447,0.1517,0.1583,0.1644 };
	double t4[] = { 0.2286,0.214,0.1997,0.1854,0.1712,0.1571,0.1437,0.1319,0.1238,0.1211,0.1231,0.128,0.1339,0.14,0.146,0.1517,0.1571 };
	double t5[] = { 0.221,0.2077,0.1946,0.1819,0.1694,0.1574,0.1462,0.1366,0.1295,0.1261,0.1261,0.1287,0.1327,0.1374,0.1422,0.1469,0.1516 };
	double t6[] = { 0.2063,0.1949,0.1841,0.1737,0.1639,0.1549,0.1469,0.1403,0.1355,0.1329,0.1322,0.1331,0.1352,0.1379,0.1409,0.1442,0.1475 };
	double t7[] = { 0.1993,0.1897,0.1806,0.1721,0.1642,0.157,0.1506,0.1453,0.1411,0.1383,0.1368,0.1364,0.1369,0.1381,0.1398,0.1418,0.144 };
	double t8[] = { 0.1927,0.1844,0.1768,0.1696,0.1631,0.1572,0.1521,0.1477,0.1443,0.1418,0.1402,0.1394,0.1393,0.1398,0.1407,0.1419,0.1434 };
	double t9[] = { 0.1892,0.182,0.1754,0.1692,0.1637,0.1586,0.1542,0.1505,0.1474,0.145,0.1432,0.1421,0.1415,0.1414,0.1417,0.1423,0.1431 };

	volat.set_vol_strike(vol_strike, 17);
	volat.set_vol_term(vol_term, 10);

	volat.set_volsurface_by_term(t0, 0, 17);
	volat.set_volsurface_by_term(t1, 1, 17);
	volat.set_volsurface_by_term(t2, 2, 17);
	volat.set_volsurface_by_term(t3, 3, 17);
	volat.set_volsurface_by_term(t4, 4, 17);
	volat.set_volsurface_by_term(t5, 5, 17);
	volat.set_volsurface_by_term(t6, 6, 17);
	volat.set_volsurface_by_term(t7, 7, 17);
	volat.set_volsurface_by_term(t8, 8, 17);
	volat.set_volsurface_by_term(t9, 9, 17);

	std::vector<double> v_rts(std::begin(arr_rts), std::end(arr_rts));
	std::vector<double> v_r(std::begin(arr_r), std::end(arr_r));
	std::vector<double> v_qts(std::begin(arr_qts), std::end(arr_qts));
	std::vector<double> v_q(std::begin(arr_q), std::end(arr_q));

	Rate r(v_r, v_rts);
	Rate q(v_q, v_qts);

	double refprice = 297.22;
	double rf_for_bs = r.getIntpRate(1.0);
	double div_for_bs = q.getIntpRate(1.0);
	double putstrike = 297.22*0.9;
	double callstrike = 297.22*1.1;
	double intpvol = volat.getInpVol(1.0, putstrike);

	vector<signed int> divexdate = {43278,43370,	43461,	43554,	43645,	43736,	43823,	43828,	43920,	44011,	44103,	44192,	44194,	44285,	44376,	44468,	44557,	44559,	44650	,44741	,44833	,44922,	44924};
	vector<double> divamount = { 0.827,	0.665,	4.614	,0.653,	0.832,	0.665	,0.054	,4.801,	0.656	,0.862,	0.668,	0.054	,4.922,	0.656	,0.862	,0.668	,0.054,	4.922,	0.656,	0.862,	0.668,	0.054,	4.922};
	Dividend div(divexdate, divamount);
	MarketParameters paras(43340, spot, volat, r, div);
	//MarketParam para(43340, spot, volat, r, q);

	PayoffPut putpay(putstrike);
	PayoffCall callpay(callstrike);
	
	EuropeanOption EurPut_discrete(refprice, 43705, putpay);
	EuropeanOption EurCall_discrete(refprice, 43705, callpay);

	//EuropeanOptionMC EurPutMC(refprice, 43705, putpay);

	EurPut_discrete.Calc(paras);
	EurCall_discrete.Calc(paras);

	//EurPutMC.Calc(para, numMC);
	/*EuropeanVanilla Vput(putpay,refprice, ed);

	EuropeanPut eput(refprice,putstrike,365);
	EuropeanCall ecall(refprice,callstrike,365);

	*/
	std::cout.precision(8);
	std::cout << std::fixed;

	//cout << volat.getBSVol(1.0, putstrike);

	//std::cout <<"eput:  s=" <<spot<<" "<< eput.pv(para)<<" vol " << volat.getInpVol(365/365,putstrike)<< "r " << r.getIntpRate(1.0) << " q " << q.getIntpRate(1.0) <<  std::endl;
	//std::cout <<"ecall: "<< ecall.pv(para)<< "s= " <<spot<<" "<<" vol " <<volat.getInpVol(365/365,callstrike)<< " r " << r.getIntpRate(1.0) << " q " << q.getIntpRate(1.0) << std::endl;
	std::vector<double> rs = EurPut_discrete.GetResult();
	vector<double> rs_call = EurCall_discrete.GetResult();

	std::cout << "pv put " << rs[0] << std::endl;
	std::cout << "delta put " << rs[1] << std::endl;
	std::cout << "gamma put " << rs[2] << std::endl;
	std::cout << "spot " << rs[5] << std::endl;
	std::cout << "BS vol= " << volat.getBSVol(1.0, putstrike) << std::endl;
	std::cout << "implied vol= " << put_iv(spot, putstrike, rf_for_bs, div_for_bs, 0.1, (43705 - 43340) / 365.0, rs[0]) << std::endl;
	cout << "closed form = " << k_fmla_BSPut(spot, putstrike, rf_for_bs, div_for_bs, volat.getBSVol(1.0, putstrike), 1.0) << endl;
	std::cout << "delta(closed, Flatvol)= " << k_fmla_BSPutDelta(spot, putstrike, rf_for_bs, div_for_bs, volat.getBSVol(1.0, putstrike), 1.0) << std::endl;
	std::cout << "gamma(closed, Flatvol)= " << k_fmla_BSGamma(spot, putstrike, rf_for_bs, div_for_bs, volat.getBSVol(1.0, putstrike), 1.0) << std::endl;
	std::cout << "\n";

	std::cout << "pv call " << rs_call[0] << std::endl;
	std::cout << "delta call " << rs_call[1] << std::endl;
	std::cout << "gamma call " << rs_call[2] << std::endl;
	std::cout << "spot " << rs_call[5] << std::endl;
	std::cout << "BS vol= " << volat.getBSVol(1.0, callstrike) << std::endl;
	std::cout << "implied vol call= " << call_iv(spot, callstrike, rf_for_bs, div_for_bs, 0.1, (43705 - 43340) / 365.0, rs_call[0]) << std::endl;
	cout << "closed form call= " << k_fmla_BSCall(spot, callstrike, rf_for_bs, div_for_bs, volat.getBSVol(1.0, callstrike), 1.0) << endl;
	std::cout << "delta call(closed, Flatvol)= " << k_fmla_BSCallDelta(spot, callstrike, rf_for_bs, div_for_bs, volat.getBSVol(1.0, callstrike), 1.0) << std::endl;
	std::cout << "gamma call(closed, Flatvol)= " << k_fmla_BSGamma(spot, callstrike, rf_for_bs, div_for_bs, volat.getBSVol(1.0, callstrike), 1.0) << std::endl;
	std::cout << "\n";

}

void test_compare_fd_mc()
{//FD�� MC���� �м� 
// 1. ki barrier�� ����� ������ discreteȿ���� ����
	double arr_rts[] = { 0.002739726,0.25,0.5,0.75,1,1.5,2,2.5,3,4,5,7,10,15,20 };
	double arr_r[] = { 1.54,1.64,1.72,1.77,1.8,1.85,1.88,1.90,1.92,1.92,1.92,1.92,1.92,1.92,1.92 };
	for (int i = 0; i<15; i++)
		arr_r[i] /= 100.0;

	double arr_qts[] = { 0.0191780821917808,0.038356164,0.057534247,0.084931507,0.104109589,0.123287671,0.142465753,0.167123288,0.252054795,0.334246575,0.419178082,0.504109589,0.580821918,0.665753425,0.747945205,0.832876712,0.915068493,1,1.084931507,1.167123288,1.252054795,1.334246575,1.419178082,1.504109589,1.583561644,1.668493151,1.750684932,1.835616438,1.917808219,	2.002739726	,2.087671233,2.169863014,2.254794521,2.336986301,2.421917808,2.506849315,2.583561644,2.668493151,2.750684932,2.835616438,2.917808219,3.002739726 };
	double arr_q[] = { 0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,4.5095,3.5958,2.9900,2.9722,2.5930,2.3094,2.4108,2.1943,2.0079,2.0613,1.9162,1.7862,2.8437,2.6742,2.5232,2.3966,2.4059,2.2935,2.3434,2.2429,2.1478,2.1699,2.0877,2.0090,2.5757,2.4858,2.4016,2.330293238,2.341357773,2.27176383,2.304693379,2.239772439,2.176421211 };
	for (int i = 0; i<42; i++)
		arr_q[i] /= 100.0;

	//double spot=297.22;
	double vol_term[] = { 0.08493150,0.16712330,0.25205480,0.50410960,0.74794520,1.00000000,1.50410960,2.00273970,2.50684930,3.00273970 }; //10terms
	double vol_strike[] = { 178.332,193.193,208.054,222.915,237.776,252.637,267.498,282.359,297.22,312.081,326.942,341.803,356.664,371.525,386.386,401.247,416.108 };//17spot
	Vol volat(10, 17);
	double t0[] = { 0.3095,0.2907,0.2719,0.2528,0.2331,0.2136,0.1816,0.1388,0.1081,0.105,0.1296,0.1606,0.1795,0.1892,0.1978,0.2057,0.2129 };
	double t1[] = { 0.2807,0.2619,0.2431,0.2239,0.2042,0.1845,0.1586,0.1285,0.1095,0.1027,0.1076,0.1306,0.1518,0.1634,0.172,0.1798,0.1869 };
	double t2[] = { 0.2621,0.2448,0.2274,0.2098,0.1916,0.172,0.1505,0.128,0.1131,0.1076,0.1125,0.1264,0.1413,0.1517,0.16,0.1676,0.1745 };
	double t3[] = { 0.2376,0.2219,0.2061,0.1902,0.1741,0.1576,0.141,0.1261,0.1169,0.1161,0.1215,0.1292,0.1371,0.1447,0.1517,0.1583,0.1644 };
	double t4[] = { 0.2286,0.214,0.1997,0.1854,0.1712,0.1571,0.1437,0.1319,0.1238,0.1211,0.1231,0.128,0.1339,0.14,0.146,0.1517,0.1571 };
	double t5[] = { 0.221,0.2077,0.1946,0.1819,0.1694,0.1574,0.1462,0.1366,0.1295,0.1261,0.1261,0.1287,0.1327,0.1374,0.1422,0.1469,0.1516 };
	double t6[] = { 0.2063,0.1949,0.1841,0.1737,0.1639,0.1549,0.1469,0.1403,0.1355,0.1329,0.1322,0.1331,0.1352,0.1379,0.1409,0.1442,0.1475 };
	double t7[] = { 0.1993,0.1897,0.1806,0.1721,0.1642,0.157,0.1506,0.1453,0.1411,0.1383,0.1368,0.1364,0.1369,0.1381,0.1398,0.1418,0.144 };
	double t8[] = { 0.1927,0.1844,0.1768,0.1696,0.1631,0.1572,0.1521,0.1477,0.1443,0.1418,0.1402,0.1394,0.1393,0.1398,0.1407,0.1419,0.1434 };
	double t9[] = { 0.1892,0.182,0.1754,0.1692,0.1637,0.1586,0.1542,0.1505,0.1474,0.145,0.1432,0.1421,0.1415,0.1414,0.1417,0.1423,0.1431 };

	volat.set_vol_strike(vol_strike, 17);
	volat.set_vol_term(vol_term, 10);

	volat.set_volsurface_by_term(t0, 0, 17);
	volat.set_volsurface_by_term(t1, 1, 17);
	volat.set_volsurface_by_term(t2, 2, 17);
	volat.set_volsurface_by_term(t3, 3, 17);
	volat.set_volsurface_by_term(t4, 4, 17);
	volat.set_volsurface_by_term(t5, 5, 17);
	volat.set_volsurface_by_term(t6, 6, 17);
	volat.set_volsurface_by_term(t7, 7, 17);
	volat.set_volsurface_by_term(t8, 8, 17);
	volat.set_volsurface_by_term(t9, 9, 17);

	std::vector<double> v_rts(std::begin(arr_rts), std::end(arr_rts));
	std::vector<double> v_r(std::begin(arr_r), std::end(arr_r));
	std::vector<double> v_qts(std::begin(arr_qts), std::end(arr_qts));
	std::vector<double> v_q(std::begin(arr_q), std::end(arr_q));

	Rate r(v_r, v_rts);
	Rate q(v_q, v_qts);

	double refprice = 297.22;


	double rf_for_bs = r.getIntpRate(1.0);
	double div_for_bs = q.getIntpRate(1.0);
	double putstrike = 297.22*0.9;
	double callstrike = 297.22*1.0;
	double upbarrier = 297.22*1.2;
	double intpvol = volat.getInpVol(1.0, putstrike);
	double rebate = 0.0;

	double const_vol = volat.getBSVol(1.0, 297.22);
	double const_rf = r.getIntpRate(1.0);
	double const_q = q.getIntpRate(1.0);

	//��ǰŸ�Ժ���
	bool is_flat_vol = false;
	int hitflag = 1;
	long nM = 30000;
	double spot = 297.22;
	//***��ǰŸ�Ժ���

	if (is_flat_vol) {
		volat.set_const_vol(const_vol);
		r.set_const_rate(const_rf);
		q.set_const_rate(const_q);
	}

	
	MarketParam para(43340, spot, volat, r, q);

	signed int expiryDate = 44436;
	int nb_autocall = 6;
	signed int auto_date[7] = { -1,43524,43705,43889,44071,44255,44436 };
	double auto_strike[7] = { -1,297.22,	297.22,	282.359	,282.359,	267.498,	267.498 };
	double auto_coupon[7] = { -1, 0.0230,	0.0460,	0.0690,	0.0920,	0.1150,	0.1380 };
	double auto_ki_barrier = refprice*0.6;
	double auto_dummy_coupon = auto_coupon[6];

	double auto_put_strike;
	auto_put_strike = refprice*1.0; // if put_strike=0, notional protected

	PayoffAutocallStd autoPayoff(nb_autocall, auto_date, auto_strike, auto_coupon, auto_ki_barrier, auto_put_strike, auto_dummy_coupon, refprice);
	AutocallOption AutoKOSPI(refprice, expiryDate, autoPayoff, hitflag);
	AutocallOption AutoKOSPI_mc(refprice, expiryDate, autoPayoff, hitflag);


	AutoKOSPI.Calc(para);
	AutoKOSPI_mc.CalcMC(para, nM);

	//	AutoKOSPI.Calc(para);

	std::vector<double> rs = AutoKOSPI.GetResult();
	std::vector<double> rs_mc = AutoKOSPI_mc.GetResult();

	std::cout.precision(8);
	std::cout << std::fixed;

	std::cout << "spot " << rs[5] << std::endl;

	std::cout << "pv(FD) " << (hitflag ? "hitted " : "not hit ")<<(is_flat_vol ? "flatvol" : "surfacevol ") <<"->" << rs[0] << std::endl;
	std::cout << "pv(MC) " << (hitflag ? "hitted " : "not hit ")<<(is_flat_vol ? "flatvol" : "surfacevol ") <<"nMC= " << nM << "-> "<<  rs_mc[0] << std::endl;


}

void test_Cal1_vs_Calc2()
{
	//Test Clac1 vs Calc2, for loop improvment
	//using namespace std::chrono;
	//double spot = 297.22;
	//auto ms3_1 = duration_cast<milliseconds>(system_clock::now().time_since_epoch());
	//test_autocall(spot, 1, surface, calc1);//pv hitted 0.98996 
	//auto  ms4_1 = duration_cast<milliseconds>(system_clock::now().time_since_epoch());
	//std::cout << "duration : " << (ms4_1.count() - ms3_1.count()) / 1000.0 << std::endl <<endl;

	//auto ms3_2 = duration_cast<milliseconds>(system_clock::now().time_since_epoch());
	//test_autocall(spot, 1, surface, calc2);  //pv hitted 0.98996 
	//auto  ms4_2 = duration_cast<milliseconds>(system_clock::now().time_since_epoch());
	//std::cout << "duration : " << (ms4_2.count() - ms3_2.count()) / 1000.0 << std::endl << endl;

	//auto ms11 = duration_cast<milliseconds>(system_clock::now().time_since_epoch());
	//test_autocall_mc(spot, 1, 10000, surface);//
	//auto ms22 = duration_cast<milliseconds>(system_clock::now().time_since_epoch());
	//std::cout << "duration : " << (ms22.count() - ms11.count()) / 1000.0 << std::endl << endl;
	double arr_rts[] = { 0.002739726,0.25,0.5,0.75,1,1.5,2,2.5,3,4,5,7,10,15,20 };
	double arr_r[] = { 1.54,1.64,1.72,1.77,1.8,1.85,1.88,1.90,1.92,1.92,1.92,1.92,1.92,1.92,1.92 };
	for (int i = 0; i<15; i++)
		arr_r[i] /= 100.0;

	double arr_qts[] = { 0.0191780821917808,0.038356164,0.057534247,0.084931507,0.104109589,0.123287671,0.142465753,0.167123288,0.252054795,0.334246575,0.419178082,0.504109589,0.580821918,0.665753425,0.747945205,0.832876712,0.915068493,1,1.084931507,1.167123288,1.252054795,1.334246575,1.419178082,1.504109589,1.583561644,1.668493151,1.750684932,1.835616438,1.917808219,	2.002739726	,2.087671233,2.169863014,2.254794521,2.336986301,2.421917808,2.506849315,2.583561644,2.668493151,2.750684932,2.835616438,2.917808219,3.002739726 };
	double arr_q[] = { 0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,4.5095,3.5958,2.9900,2.9722,2.5930,2.3094,2.4108,2.1943,2.0079,2.0613,1.9162,1.7862,2.8437,2.6742,2.5232,2.3966,2.4059,2.2935,2.3434,2.2429,2.1478,2.1699,2.0877,2.0090,2.5757,2.4858,2.4016,2.330293238,2.341357773,2.27176383,2.304693379,2.239772439,2.176421211 };
	for (int i = 0; i<42; i++)
		arr_q[i] /= 100.0;

	//double spot=297.22;
	double vol_term[] = { 0.08493150,0.16712330,0.25205480,0.50410960,0.74794520,1.00000000,1.50410960,2.00273970,2.50684930,3.00273970 }; //10terms
	double vol_strike[] = { 178.332,193.193,208.054,222.915,237.776,252.637,267.498,282.359,297.22,312.081,326.942,341.803,356.664,371.525,386.386,401.247,416.108 };//17spot
	Vol volat(10, 17);
	double t0[] = { 0.3095,0.2907,0.2719,0.2528,0.2331,0.2136,0.1816,0.1388,0.1081,0.105,0.1296,0.1606,0.1795,0.1892,0.1978,0.2057,0.2129 };
	double t1[] = { 0.2807,0.2619,0.2431,0.2239,0.2042,0.1845,0.1586,0.1285,0.1095,0.1027,0.1076,0.1306,0.1518,0.1634,0.172,0.1798,0.1869 };
	double t2[] = { 0.2621,0.2448,0.2274,0.2098,0.1916,0.172,0.1505,0.128,0.1131,0.1076,0.1125,0.1264,0.1413,0.1517,0.16,0.1676,0.1745 };
	double t3[] = { 0.2376,0.2219,0.2061,0.1902,0.1741,0.1576,0.141,0.1261,0.1169,0.1161,0.1215,0.1292,0.1371,0.1447,0.1517,0.1583,0.1644 };
	double t4[] = { 0.2286,0.214,0.1997,0.1854,0.1712,0.1571,0.1437,0.1319,0.1238,0.1211,0.1231,0.128,0.1339,0.14,0.146,0.1517,0.1571 };
	double t5[] = { 0.221,0.2077,0.1946,0.1819,0.1694,0.1574,0.1462,0.1366,0.1295,0.1261,0.1261,0.1287,0.1327,0.1374,0.1422,0.1469,0.1516 };
	double t6[] = { 0.2063,0.1949,0.1841,0.1737,0.1639,0.1549,0.1469,0.1403,0.1355,0.1329,0.1322,0.1331,0.1352,0.1379,0.1409,0.1442,0.1475 };
	double t7[] = { 0.1993,0.1897,0.1806,0.1721,0.1642,0.157,0.1506,0.1453,0.1411,0.1383,0.1368,0.1364,0.1369,0.1381,0.1398,0.1418,0.144 };
	double t8[] = { 0.1927,0.1844,0.1768,0.1696,0.1631,0.1572,0.1521,0.1477,0.1443,0.1418,0.1402,0.1394,0.1393,0.1398,0.1407,0.1419,0.1434 };
	double t9[] = { 0.1892,0.182,0.1754,0.1692,0.1637,0.1586,0.1542,0.1505,0.1474,0.145,0.1432,0.1421,0.1415,0.1414,0.1417,0.1423,0.1431 };

	volat.set_vol_strike(vol_strike, 17);
	volat.set_vol_term(vol_term, 10);

	volat.set_volsurface_by_term(t0, 0, 17);
	volat.set_volsurface_by_term(t1, 1, 17);
	volat.set_volsurface_by_term(t2, 2, 17);
	volat.set_volsurface_by_term(t3, 3, 17);
	volat.set_volsurface_by_term(t4, 4, 17);
	volat.set_volsurface_by_term(t5, 5, 17);
	volat.set_volsurface_by_term(t6, 6, 17);
	volat.set_volsurface_by_term(t7, 7, 17);
	volat.set_volsurface_by_term(t8, 8, 17);
	volat.set_volsurface_by_term(t9, 9, 17);

	std::vector<double> v_rts(std::begin(arr_rts), std::end(arr_rts));
	std::vector<double> v_r(std::begin(arr_r), std::end(arr_r));
	std::vector<double> v_qts(std::begin(arr_qts), std::end(arr_qts));
	std::vector<double> v_q(std::begin(arr_q), std::end(arr_q));

	Rate r(v_r, v_rts);
	Rate q(v_q, v_qts);

	double refprice = 297.22;


	double rf_for_bs = r.getIntpRate(1.0);
	double div_for_bs = q.getIntpRate(1.0);
	double putstrike = 297.22*0.9;
	double callstrike = 297.22*1.0;
	double upbarrier = 297.22*1.2;
	double intpvol = volat.getInpVol(1.0, putstrike);
	double rebate = 0.0;

	double const_vol = volat.getBSVol(1.0, 297.22);
	double const_rf = r.getIntpRate(1.0);
	double const_q = q.getIntpRate(1.0);

	//��ǰŸ�Ժ���
	bool is_flat_vol = true;
	int hitflag = 1;
	long nM = 30000;
	double spot = 297.22;
	//***��ǰŸ�Ժ���

	if (is_flat_vol) {
		volat.set_const_vol(const_vol);
		r.set_const_rate(const_rf);
		q.set_const_rate(const_q);
	}

	MarketParam para(43340, spot, volat, r, q);

	signed int expiryDate = 44436;
	int nb_autocall = 6;
	signed int auto_date[7] = { -1,43524,43705,43889,44071,44255,44436 };
	double auto_strike[7] = { -1,297.22,	297.22,	282.359	,282.359,	267.498,	267.498 };
	double auto_coupon[7] = { -1, 0.0230,	0.0460,	0.0690,	0.0920,	0.1150,	0.1380 };
	double auto_ki_barrier = refprice*0.6;
	double auto_dummy_coupon = auto_coupon[6];

	double auto_put_strike;
	auto_put_strike = refprice*1.0; // if put_strike=0, notional protected

	PayoffAutocallStd autoPayoff(nb_autocall, auto_date, auto_strike, auto_coupon, auto_ki_barrier, auto_put_strike, auto_dummy_coupon, refprice);
	AutocallOption AutoKOSPI(refprice, expiryDate, autoPayoff, hitflag);
	AutocallOption AutoKOSPI2(refprice, expiryDate, autoPayoff, hitflag);


	AutoKOSPI.Calc(para);
	AutoKOSPI2.Calc_old(para);


	//	AutoKOSPI.Calc(para);

	std::vector<double> rs = AutoKOSPI.GetResult();
	std::vector<double> rs2 = AutoKOSPI2.GetResult();

	std::cout.precision(8);
	std::cout << std::fixed;

	std::cout << "spot " << rs[5] << std::endl;
	std::cout << "pv " << (hitflag ? "hitted  " : "not hit  ") << (is_flat_vol ? "flatvol" : "surfacevol ") << rs[0] << std::endl;
	std::cout << "pv " << (hitflag ? "hitted  " : "not hit  ") << (is_flat_vol ? "flatvol" : "surfacevol ") << rs2[0] << std::endl;

}

void test_calc2_mc_for_vanilla(long n)
{

	double arr_rts[] = { 0.002739726,0.25,0.5,0.75,1,1.5,2,2.5,3,4,5,7,10,15,20 };
	double arr_r[] = { 1.54,1.64,1.72,1.77,1.8,1.85,1.88,1.90,1.92,1.92,1.92,1.92,1.92,1.92,1.92 };
	for (int i = 0; i<15; i++)
		arr_r[i] /= 100.0;

	double arr_qts[] = { 0.0191780821917808,0.038356164,0.057534247,0.084931507,0.104109589,0.123287671,0.142465753,0.167123288,0.252054795,0.334246575,0.419178082,0.504109589,0.580821918,0.665753425,0.747945205,0.832876712,0.915068493,1,1.084931507,1.167123288,1.252054795,1.334246575,1.419178082,1.504109589,1.583561644,1.668493151,1.750684932,1.835616438,1.917808219,	2.002739726	,2.087671233,2.169863014,2.254794521,2.336986301,2.421917808,2.506849315,2.583561644,2.668493151,2.750684932,2.835616438,2.917808219,3.002739726 };
	double arr_q[] = { 0.00000,0.00000,0.00000,2.57097, 2.09737,1.77112,1.53270, 1.30656 ,0.86631 ,5.16283, 4.11677,3.42318,3.34816,2.92103,2.60139,2.67302,2.43293,2.22630,2.26258, 2.10325,1.96057,3.00733,2.82806 ,2.66837, 2.53449,2.53675,2.41823 ,2.46233 ,2.35680 ,2.25685 ,2.27446 ,2.18831 ,2.10588 ,2.66917,2.57598,2.48871,2.41481,2.42319,2.35115 ,2.38170 ,2.31461 ,2.24914 };
	for (int i = 0; i<42; i++)
		arr_q[i] /= 100.0;

	//double spot=297.22;
	double vol_term[] = { 0.08493150,0.16712330,0.25205480,0.50410960,0.74794520,1.00000000,1.50410960,2.00273970,2.50684930,3.00273970 }; //10terms
	double vol_strike[] = { 178.332,193.193,208.054,222.915,237.776,252.637,267.498,282.359,297.22,312.081,326.942,341.803,356.664,371.525,386.386,401.247,416.108 };//17spot
	Vol volat(10, 17);
	double t0[] = { 0.3095,0.2907,0.2719,0.2528,0.2331,0.2136,0.1816,0.1388,0.1081,0.105,0.1296,0.1606,0.1795,0.1892,0.1978,0.2057,0.2129 };
	double t1[] = { 0.2807,0.2619,0.2431,0.2239,0.2042,0.1845,0.1586,0.1285,0.1095,0.1027,0.1076,0.1306,0.1518,0.1634,0.172,0.1798,0.1869 };
	double t2[] = { 0.2621,0.2448,0.2274,0.2098,0.1916,0.172,0.1505,0.128,0.1131,0.1076,0.1125,0.1264,0.1413,0.1517,0.16,0.1676,0.1745 };
	double t3[] = { 0.2376,0.2219,0.2061,0.1902,0.1741,0.1576,0.141,0.1261,0.1169,0.1161,0.1215,0.1292,0.1371,0.1447,0.1517,0.1583,0.1644 };
	double t4[] = { 0.2286,0.214,0.1997,0.1854,0.1712,0.1571,0.1437,0.1319,0.1238,0.1211,0.1231,0.128,0.1339,0.14,0.146,0.1517,0.1571 };
	double t5[] = { 0.221,0.2077,0.1946,0.1819,0.1694,0.1574,0.1462,0.1366,0.1295,0.1261,0.1261,0.1287,0.1327,0.1374,0.1422,0.1469,0.1516 };
	double t6[] = { 0.2063,0.1949,0.1841,0.1737,0.1639,0.1549,0.1469,0.1403,0.1355,0.1329,0.1322,0.1331,0.1352,0.1379,0.1409,0.1442,0.1475 };
	double t7[] = { 0.1993,0.1897,0.1806,0.1721,0.1642,0.157,0.1506,0.1453,0.1411,0.1383,0.1368,0.1364,0.1369,0.1381,0.1398,0.1418,0.144 };
	double t8[] = { 0.1927,0.1844,0.1768,0.1696,0.1631,0.1572,0.1521,0.1477,0.1443,0.1418,0.1402,0.1394,0.1393,0.1398,0.1407,0.1419,0.1434 };
	double t9[] = { 0.1892,0.182,0.1754,0.1692,0.1637,0.1586,0.1542,0.1505,0.1474,0.145,0.1432,0.1421,0.1415,0.1414,0.1417,0.1423,0.1431 };

	volat.set_vol_strike(vol_strike, 17);
	volat.set_vol_term(vol_term, 10);

	volat.set_volsurface_by_term(t0, 0, 17);
	volat.set_volsurface_by_term(t1, 1, 17);
	volat.set_volsurface_by_term(t2, 2, 17);
	volat.set_volsurface_by_term(t3, 3, 17);
	volat.set_volsurface_by_term(t4, 4, 17);
	volat.set_volsurface_by_term(t5, 5, 17);
	volat.set_volsurface_by_term(t6, 6, 17);
	volat.set_volsurface_by_term(t7, 7, 17);
	volat.set_volsurface_by_term(t8, 8, 17);
	volat.set_volsurface_by_term(t9, 9, 17);

	std::vector<double> v_rts(std::begin(arr_rts), std::end(arr_rts));
	std::vector<double> v_r(std::begin(arr_r), std::end(arr_r));
	std::vector<double> v_qts(std::begin(arr_qts), std::end(arr_qts));
	std::vector<double> v_q(std::begin(arr_q), std::end(arr_q));

	Rate r(v_r, v_rts);
	Rate q(v_q, v_qts);

	double spot = 297.22;
	//***��ǰŸ�Ժ���

	signed int vd = 43340;
	signed int exd = 43705;

	double refprice = 297.22;
	double rf_for_bs = r.getIntpRate((exd - vd) / 365.0);
	cout << "rf_for_bs " << rf_for_bs << "\n";
	double div_for_bs = q.getIntpRate((exd - vd) / 365.0);
	cout << "div_for_bs " << div_for_bs << "\n";

	double putstrike = spot*0.9;
	double vol_bs = volat.getBSVol((exd - vd) / 365.0, putstrike);

	MarketParam para(vd, spot, volat, r, q);

	PayoffPut putpay(putstrike);

	EuropeanOption EurPut(refprice, exd, putpay);
	EuropeanOption EurPut2(refprice, exd, putpay);

	EuropeanOptionMC EurPutMC(refprice, exd, putpay);

	EurPut.Calc(para);
	EurPut2.Calc2(para);
	EurPutMC.Calc(para,n);
	std::cout.precision(8);
	std::cout << std::fixed;

	std::vector<double> rs = EurPut.GetResult();
	std::vector<double> rs2 = EurPut2.GetResult();
	vector<double> rs3 = EurPutMC.GetResult();
	double bs_put_value = k_fmla_BSPut(spot, putstrike, rf_for_bs, div_for_bs, vol_bs, (exd - vd) / 365.0);
	double bs_put_vega = k_fmla_BSVega(spot, putstrike, rf_for_bs, div_for_bs, vol_bs, (exd - vd) / 365.0);

	std::cout << "pv by calc1 localvol r,q term " << rs[0] << "=%price " << rs[0] / spot * 100 << "%" << std::endl;
	std::cout << "pv by calc2 localvol r,q term " << rs2[0] << "=%price " << rs2[0] / spot * 100 << "%" << std::endl;
	cout << "pv by mc"  << rs3[0] << "=%price " << rs3[0] / spot * 100 << "%" << std::endl;
	std::cout << "BS vol=" << vol_bs << "=" << vol_bs * 100 << "%" << std::endl;
	cout << "BS put value(closed) " << bs_put_value << " error/spot " << (rs[0] - bs_put_value) / spot << "=" << (rs[0] - bs_put_value) / spot * 10000 << " bp" << endl;
	cout << "BS put vega(%)/spot " << bs_put_vega / 100.0 / spot << "=" << bs_put_vega * 100.0 / spot << " bp" << endl;
	cout << "mc vs calc2 for vanilla : price diff 2bp, 1/10 vega\n";
}

void test_calc1_vs_calc2_for_vanilla()
{

	double arr_rts[] = { 0.002739726,0.25,0.5,0.75,1,1.5,2,2.5,3,4,5,7,10,15,20 };
	double arr_r[] = { 1.54,1.64,1.72,1.77,1.8,1.85,1.88,1.90,1.92,1.92,1.92,1.92,1.92,1.92,1.92 };

	for (int i = 0; i<15; i++)
		arr_r[i] /= 100.0;

	double arr_qts[] = { 0.0191780821917808,0.038356164,0.057534247,0.084931507,0.104109589,0.123287671,0.142465753,0.167123288,0.252054795,0.334246575,0.419178082,0.504109589,0.580821918,0.665753425,0.747945205,0.832876712,0.915068493,1,1.084931507,1.167123288,1.252054795,1.334246575,1.419178082,1.504109589,1.583561644,1.668493151,1.750684932,1.835616438,1.917808219,	2.002739726	,2.087671233,2.169863014,2.254794521,2.336986301,2.421917808,2.506849315,2.583561644,2.668493151,2.750684932,2.835616438,2.917808219,3.002739726 };
	double arr_q[] = {0.00000,0.00000,0.00000,2.63436,2.14908,1.81478,1.57048,1.33877,0.88766,5.31382,4.23716,3.52329,3.05795,2.99785,2.66841,2.39631,2.48698,2.27576,2.30383,2.14159,1.99631,1.88696,2.91222,2.74778,2.60992,2.60935,2.48684,2.37178,2.42136,2.31867,2.22434,2.24367,2.15915,2.09099,2.70142,2.60990,2.53241,2.53452,2.45878,2.38514,2.41735,2.34898};
	for (int i = 0; i<42; i++)
		arr_q[i] /= 100.0;

	//double spot=297.22;
	double vol_term[] = {0.083333,0.166667,0.250000,0.500000,0.750000,1.000000,1.500000,2.000000,2.500000,3.000000};
	double vol_strike[] = { 178.332,193.193,208.054,222.915,237.776,252.637,267.498,282.359,297.22,312.081,326.942,341.803,356.664,371.525,386.386,401.247,416.108 };//17spot
	Vol volat(10, 17);
	double t0[] = { 0.3095,0.2907,0.2719,0.2528,0.2331,0.2136,0.1816,0.1388,0.1081,0.105,0.1296,0.1606,0.1795,0.1892,0.1978,0.2057,0.2129 };
	double t1[] = { 0.2807,0.2619,0.2431,0.2239,0.2042,0.1845,0.1586,0.1285,0.1095,0.1027,0.1076,0.1306,0.1518,0.1634,0.172,0.1798,0.1869 };
	double t2[] = { 0.2621,0.2448,0.2274,0.2098,0.1916,0.172,0.1505,0.128,0.1131,0.1076,0.1125,0.1264,0.1413,0.1517,0.16,0.1676,0.1745 };
	double t3[] = { 0.2376,0.2219,0.2061,0.1902,0.1741,0.1576,0.141,0.1261,0.1169,0.1161,0.1215,0.1292,0.1371,0.1447,0.1517,0.1583,0.1644 };
	double t4[] = { 0.2286,0.214,0.1997,0.1854,0.1712,0.1571,0.1437,0.1319,0.1238,0.1211,0.1231,0.128,0.1339,0.14,0.146,0.1517,0.1571 };
	double t5[] = { 0.221,0.2077,0.1946,0.1819,0.1694,0.1574,0.1462,0.1366,0.1295,0.1261,0.1261,0.1287,0.1327,0.1374,0.1422,0.1469,0.1516 };
	double t6[] = { 0.2063,0.1949,0.1841,0.1737,0.1639,0.1549,0.1469,0.1403,0.1355,0.1329,0.1322,0.1331,0.1352,0.1379,0.1409,0.1442,0.1475 };
	double t7[] = { 0.1993,0.1897,0.1806,0.1721,0.1642,0.157,0.1506,0.1453,0.1411,0.1383,0.1368,0.1364,0.1369,0.1381,0.1398,0.1418,0.144 };
	double t8[] = { 0.1927,0.1844,0.1768,0.1696,0.1631,0.1572,0.1521,0.1477,0.1443,0.1418,0.1402,0.1394,0.1393,0.1398,0.1407,0.1419,0.1434 };
	double t9[] = { 0.1892,0.182,0.1754,0.1692,0.1637,0.1586,0.1542,0.1505,0.1474,0.145,0.1432,0.1421,0.1415,0.1414,0.1417,0.1423,0.1431 };

	volat.set_vol_strike(vol_strike, 17);
	volat.set_vol_term(vol_term, 10);

	volat.set_volsurface_by_term(t0, 0, 17);
	volat.set_volsurface_by_term(t1, 1, 17);
	volat.set_volsurface_by_term(t2, 2, 17);
	volat.set_volsurface_by_term(t3, 3, 17);
	volat.set_volsurface_by_term(t4, 4, 17);
	volat.set_volsurface_by_term(t5, 5, 17);
	volat.set_volsurface_by_term(t6, 6, 17);
	volat.set_volsurface_by_term(t7, 7, 17);
	volat.set_volsurface_by_term(t8, 8, 17);
	volat.set_volsurface_by_term(t9, 9, 17);

	std::vector<double> v_rts(std::begin(arr_rts), std::end(arr_rts));
	std::vector<double> v_r(std::begin(arr_r), std::end(arr_r));
	std::vector<double> v_qts(std::begin(arr_qts), std::end(arr_qts));
	std::vector<double> v_q(std::begin(arr_q), std::end(arr_q));

	Rate r(v_r, v_rts);
	Rate q(v_q, v_qts);


	//double intpvol = volat.getInpVol(1.0, putstrike);  //flat interpolation use .getBSVol

	//��ǰŸ�Ժ���
	//bool is_flat_vol = true;
	//int hitflag = 1;
	//long nM = 30000;
	double spot = 297.22;
	//***��ǰŸ�Ժ���

	signed int vd = 43340;
	signed int exd = 43705;

	double refprice = 297.22;
	double rf_for_bs = r.getIntpRate((exd-vd)/365.0);
	cout << "rf_for_bs "<<rf_for_bs << "\n";
	double div_for_bs = q.getIntpRate((exd - vd) / 365.0);
	cout << "div_for_bs "<<div_for_bs << "\n";

	double putstrike = spot;
	//double callstrike = spot*1.1;
	double vol_bs = volat.getBSVol((exd - vd) / 365.0, putstrike);

	MarketParam para(vd, spot, volat, r, q);

	PayoffPut putpay(putstrike);
	
	EuropeanOption EurPut(refprice, exd, putpay);
	EuropeanOption EurPut2(refprice, exd, putpay);

	EuropeanOptionMC EurPutMC(refprice, exd, putpay);

	EurPut.Calc(para);
	EurPut2.Calc2(para);
	//EurPutMC.Calc(para, nM);
	/*EuropeanVanilla Vput(putpay,refprice, ed);

	EuropeanPut eput(refprice,putstrike,365);
	EuropeanCall ecall(refprice,callstrike,365);

	*/
	std::cout.precision(8);
	std::cout << std::fixed;

	//std::cout <<"eput:  s=" <<spot<<" "<< eput.pv(para)<<" vol " << volat.getInpVol(365/365,putstrike)<< "r " << r.getIntpRate(1.0) << " q " << q.getIntpRate(1.0) <<  std::endl;
	//std::cout <<"ecall: "<< ecall.pv(para)<< "s= " <<spot<<" "<<" vol " <<volat.getInpVol(365/365,callstrike)<< " r " << r.getIntpRate(1.0) << " q " << q.getIntpRate(1.0) << std::endl;
	std::vector<double> rs = EurPut.GetResult();
	std::vector<double> rs2 = EurPut2.GetResult();
	double bs_put_value = k_fmla_BSPut(spot, putstrike, rf_for_bs, div_for_bs, vol_bs, (exd - vd) / 365.0);
	double bs_put_vega = k_fmla_BSVega(spot, putstrike, rf_for_bs, div_for_bs, vol_bs, (exd - vd) / 365.0);

	std::cout << "pv by calc1 localvol r,q term " << rs[0] << "=%price " << rs[0]/spot*100 << "%" <<std::endl;
	std::cout << "pv by calc2 localvol r,q term " << rs2[0] << "=%price " << rs2[0] / spot*100 << "%"<< std::endl;
	std::cout << "BS vol=" << vol_bs << "=" << vol_bs*100 << "%" << std::endl;
	cout << "BS put value(closed) " << bs_put_value << " error/spot " << (rs[0] - bs_put_value) / spot << "=" << (rs[0] - bs_put_value) / spot*10000 << " bp" << endl;
	cout << "BS put vega(%)/spot " << bs_put_vega /100.0/spot << "=" << bs_put_vega * 100.0 / spot << " bp"<< endl;
	

	//////////////////////////
	cout << "\n FDM���� Flat vol pricing\n";
	//double vol_term[] = { 0.08493150,0.16712330,0.25205480,0.50410960,0.74794520,1.00000000,1.50410960,2.00273970,2.50684930,3.00273970 }; //10terms
	//double vol_strike[] = { 178.332,193.193,208.054,222.915,237.776,252.637,267.498,282.359,297.22,312.081,326.942,341.803,356.664,371.525,386.386,401.247,416.108 };//17spot
	Vol volat_flat(10, 17);
	double t0_flat[] = { vol_bs,vol_bs,vol_bs,vol_bs,vol_bs,vol_bs,vol_bs,vol_bs,vol_bs,vol_bs,vol_bs,vol_bs,vol_bs,vol_bs,vol_bs,vol_bs,vol_bs };

	volat_flat.set_vol_strike(vol_strike, 17);
	volat_flat.set_vol_term(vol_term, 10);

	volat_flat.set_volsurface_by_term(t0_flat, 0, 17);
	volat_flat.set_volsurface_by_term(t0_flat, 1, 17);
	volat_flat.set_volsurface_by_term(t0_flat, 2, 17);
	volat_flat.set_volsurface_by_term(t0_flat, 3, 17);
	volat_flat.set_volsurface_by_term(t0_flat, 4, 17);
	volat_flat.set_volsurface_by_term(t0_flat, 5, 17);
	volat_flat.set_volsurface_by_term(t0_flat, 6, 17);
	volat_flat.set_volsurface_by_term(t0_flat, 7, 17);
	volat_flat.set_volsurface_by_term(t0_flat, 8, 17);
	volat_flat.set_volsurface_by_term(t0_flat, 9, 17);

	MarketParam para_flat(vd, spot, volat_flat, r, q);

	EuropeanOption EurPut_flat(refprice, exd, putpay);
	EuropeanOption EurPut2_flat(refprice, exd, putpay);
	EurPut_flat.Calc(para_flat);
	EurPut2_flat.Calc2(para_flat);
	std::vector<double> rs_flat = EurPut_flat.GetResult();
	std::vector<double> rs2_flat = EurPut2_flat.GetResult();
	std::cout << "pv by calc1 flat_vol r,q term struct " << rs_flat[0] << "=%price " << rs_flat[0] / spot * 100 << "%" << std::endl;
	std::cout << "pv by calc2 flat_vol r,q term struct " << rs2_flat[0] << "=%price " << rs2_flat[0] / spot * 100 << "%" << std::endl;
	cout << "flat vs surface �������̴� 2bp�������� ��ȣ��\n";

	////////////////////////////////
	cout << "\n FDM���� Flat vol, flat r,div curve pricing\n";
	//double arr_rts[] = { 0.002739726,0.25,0.5,0.75,1,1.5,2,2.5,3,4,5,7,10,15,20 };
	//double arr_r_flat[] = { rf_for_bs,rf_for_bs,rf_for_bs,rf_for_bs,rf_for_bs,rf_for_bs,rf_for_bs,rf_for_bs,rf_for_bs,rf_for_bs,rf_for_bs,rf_for_bs,rf_for_bs,rf_for_bs,rf_for_bs };
	double arr_r_flat[15];
	fill_n(arr_r_flat, 15, rf_for_bs);

	//double arr_qts[] = { 0.0191780821917808,0.038356164,0.057534247,0.084931507,0.104109589,0.123287671,0.142465753,0.167123288,0.252054795,0.334246575,0.419178082,0.504109589,0.580821918,0.665753425,0.747945205,0.832876712,0.915068493,1,1.084931507,1.167123288,1.252054795,1.334246575,1.419178082,1.504109589,1.583561644,1.668493151,1.750684932,1.835616438,1.917808219,	2.002739726	,2.087671233,2.169863014,2.254794521,2.336986301,2.421917808,2.506849315,2.583561644,2.668493151,2.750684932,2.835616438,2.917808219,3.002739726 };
	//double arr_q_flat[] = { div_for_bs,0.00000,0.00000,2.57097, 2.09737,1.77112,1.53270, 1.30656 ,0.86631 ,5.16283, 4.11677,3.42318,3.34816,2.92103,2.60139,2.67302,2.43293,2.22630,2.26258, 2.10325,1.96057,3.00733,2.82806 ,2.66837, 2.53449,2.53675,2.41823 ,2.46233 ,2.35680 ,2.25685 ,2.27446 ,2.18831 ,2.10588 ,2.66917,2.57598,2.48871,2.41481,2.42319,2.35115 ,2.38170 ,2.31461 ,2.24914 };
	double arr_q_flat[42];
	fill_n(arr_q_flat, 42, div_for_bs);

	//std::vector<double> v_rts(std::begin(arr_rts), std::end(arr_rts));
	std::vector<double> v_r_flat(std::begin(arr_r_flat), std::end(arr_r_flat));
	//std::vector<double> v_qts(std::begin(arr_qts), std::end(arr_qts));
	std::vector<double> v_q_flat(std::begin(arr_q_flat), std::end(arr_q_flat));

	Rate r_flat(v_r_flat, v_rts);
	Rate q_flat(v_q_flat, v_qts);

	MarketParam para_volflat_rqflat(vd, spot, volat_flat, r_flat, q_flat);
	EurPut_flat.Calc(para_volflat_rqflat);
	EurPut2_flat.Calc2(para_volflat_rqflat);

	std::vector<double> rs_flat_rqflat = EurPut_flat.GetResult();
	std::vector<double> rs2_flat_rqflat = EurPut2_flat.GetResult();
	std::cout << "pv by calc1 flat vol,r,q  " << rs_flat_rqflat[0] << "=%price " << rs_flat_rqflat[0] / spot * 100 << "%" << std::endl;
	std::cout << "pv by calc2 flat vol,r,q  " << rs2_flat_rqflat[0] << "=%price " << rs2_flat_rqflat[0] / spot * 100 << "%" << std::endl;
	cout << "vol,r,q,flat vs surface �������̴� 3bp(2bp from vol, 1bp from rq) �������� ��ȣ��\n";

}

void test_calc2_for_vanilla_param_params()
{

	double arr_rts[] = { 0.002739726,0.25,0.5,0.75,1,1.5,2,2.5,3,4,5,7,10,15,20 };
	double arr_r[] = { 1.54,1.64,1.72,1.77,1.8,1.85,1.88,1.90,1.92,1.92,1.92,1.92,1.92,1.92,1.92 };
	for (int i = 0; i<15; i++)
		arr_r[i] /= 100.0;

	double arr_qts[] = { 0.0191780821917808,0.038356164,0.057534247,0.084931507,0.104109589,0.123287671,0.142465753,0.167123288,0.252054795,0.334246575,0.419178082,0.504109589,0.580821918,0.665753425,0.747945205,0.832876712,0.915068493,1,1.084931507,1.167123288,1.252054795,1.334246575,1.419178082,1.504109589,1.583561644,1.668493151,1.750684932,1.835616438,1.917808219,	2.002739726	,2.087671233,2.169863014,2.254794521,2.336986301,2.421917808,2.506849315,2.583561644,2.668493151,2.750684932,2.835616438,2.917808219,3.002739726 };
	double arr_q[] = { 0.00000,0.00000,0.00000,2.57097, 2.09737,1.77112,1.53270, 1.30656 ,0.86631 ,5.16283, 4.11677,3.42318,3.34816,2.92103,2.60139,2.67302,2.43293,2.22630,2.26258, 2.10325,1.96057,3.00733,2.82806 ,2.66837, 2.53449,2.53675,2.41823 ,2.46233 ,2.35680 ,2.25685 ,2.27446 ,2.18831 ,2.10588 ,2.66917,2.57598,2.48871,2.41481,2.42319,2.35115 ,2.38170 ,2.31461 ,2.24914 };
	for (int i = 0; i<42; i++)
		arr_q[i] /= 100.0;

	//double spot=297.22;
	double vol_term[] = { 0.08493150,0.16712330,0.25205480,0.50410960,0.74794520,1.00000000,1.50410960,2.00273970,2.50684930,3.00273970 }; //10terms
	double vol_strike[] = { 178.332,193.193,208.054,222.915,237.776,252.637,267.498,282.359,297.22,312.081,326.942,341.803,356.664,371.525,386.386,401.247,416.108 };//17spot
	Vol volat(10, 17);
	double t0[] = { 0.3095,0.2907,0.2719,0.2528,0.2331,0.2136,0.1816,0.1388,0.1081,0.105,0.1296,0.1606,0.1795,0.1892,0.1978,0.2057,0.2129 };
	double t1[] = { 0.2807,0.2619,0.2431,0.2239,0.2042,0.1845,0.1586,0.1285,0.1095,0.1027,0.1076,0.1306,0.1518,0.1634,0.172,0.1798,0.1869 };
	double t2[] = { 0.2621,0.2448,0.2274,0.2098,0.1916,0.172,0.1505,0.128,0.1131,0.1076,0.1125,0.1264,0.1413,0.1517,0.16,0.1676,0.1745 };
	double t3[] = { 0.2376,0.2219,0.2061,0.1902,0.1741,0.1576,0.141,0.1261,0.1169,0.1161,0.1215,0.1292,0.1371,0.1447,0.1517,0.1583,0.1644 };
	double t4[] = { 0.2286,0.214,0.1997,0.1854,0.1712,0.1571,0.1437,0.1319,0.1238,0.1211,0.1231,0.128,0.1339,0.14,0.146,0.1517,0.1571 };
	double t5[] = { 0.221,0.2077,0.1946,0.1819,0.1694,0.1574,0.1462,0.1366,0.1295,0.1261,0.1261,0.1287,0.1327,0.1374,0.1422,0.1469,0.1516 };
	double t6[] = { 0.2063,0.1949,0.1841,0.1737,0.1639,0.1549,0.1469,0.1403,0.1355,0.1329,0.1322,0.1331,0.1352,0.1379,0.1409,0.1442,0.1475 };
	double t7[] = { 0.1993,0.1897,0.1806,0.1721,0.1642,0.157,0.1506,0.1453,0.1411,0.1383,0.1368,0.1364,0.1369,0.1381,0.1398,0.1418,0.144 };
	double t8[] = { 0.1927,0.1844,0.1768,0.1696,0.1631,0.1572,0.1521,0.1477,0.1443,0.1418,0.1402,0.1394,0.1393,0.1398,0.1407,0.1419,0.1434 };
	double t9[] = { 0.1892,0.182,0.1754,0.1692,0.1637,0.1586,0.1542,0.1505,0.1474,0.145,0.1432,0.1421,0.1415,0.1414,0.1417,0.1423,0.1431 };

	volat.set_vol_strike(vol_strike, 17);
	volat.set_vol_term(vol_term, 10);

	volat.set_volsurface_by_term(t0, 0, 17);
	volat.set_volsurface_by_term(t1, 1, 17);
	volat.set_volsurface_by_term(t2, 2, 17);
	volat.set_volsurface_by_term(t3, 3, 17);
	volat.set_volsurface_by_term(t4, 4, 17);
	volat.set_volsurface_by_term(t5, 5, 17);
	volat.set_volsurface_by_term(t6, 6, 17);
	volat.set_volsurface_by_term(t7, 7, 17);
	volat.set_volsurface_by_term(t8, 8, 17);
	volat.set_volsurface_by_term(t9, 9, 17);

	std::vector<double> v_rts(std::begin(arr_rts), std::end(arr_rts));
	std::vector<double> v_r(std::begin(arr_r), std::end(arr_r));
	std::vector<double> v_qts(std::begin(arr_qts), std::end(arr_qts));
	std::vector<double> v_q(std::begin(arr_q), std::end(arr_q));

	Rate r(v_r, v_rts);
	Rate q(v_q, v_qts);

	//��ǰŸ�Ժ���
	//bool is_flat_vol = true;
	//int hitflag = 1;
	//long nM = 30000;
	double spot = 297.22;
	//***��ǰŸ�Ժ���

	signed int vd = 43340;
	signed int exd = 43705;

	double refprice = 297.22;
	double rf_for_bs = r.getIntpRate((exd - vd) / 365.0);
	cout << "rf_for_bs " << rf_for_bs << "\n";
	double div_for_bs = q.getIntpRate((exd - vd) / 365.0);
	cout << "div_for_bs " << div_for_bs << "\n";

	double putstrike = spot*0.9;
	//double callstrike = spot*1.1;
	double vol_bs = volat.getBSVol((exd - vd) / 365.0, putstrike);

	//MarketParam para(vd, spot, volat, r, q);
	
	vector<signed int> divexdate = { 43278,43370,	43461,	43554,	43645,	43736,	43823,	43828,	43920,	44011,	44103,	44192,	44194,	44285,	44376,	44468,	44557,	44559,	44650	,44741	,44833	,44922,	44924 };
	vector<double> divamount = { 0.827,	0.665,	4.614	,0.653,	0.832,	0.665	,0.054	,4.801,	0.656	,0.862,	0.668,	0.054	,4.922,	0.656	,0.862	,0.668	,0.054,	4.922,	0.656,	0.862,	0.668,	0.054,	4.922 };
	Dividend div(divexdate, divamount);
	
	Rate r_from_div = div.getDividendCurve(v_rts, vd, spot);

	MarketParameters paras(43340, spot, volat, r, div);
	MarketParam para(43340, spot, volat, r, q);


	PayoffPut putpay(putstrike);

	EuropeanOption EurPut(refprice, exd, putpay);
	EuropeanOption EurPut2(refprice, exd, putpay);

	EuropeanOptionMC EurPutMC(refprice, exd, putpay);

	EurPut.Calc(para);
	EurPut2.Calc2(para);

	std::cout.precision(8);
	std::cout << std::fixed;

	//std::cout <<"eput:  s=" <<spot<<" "<< eput.pv(para)<<" vol " << volat.getInpVol(365/365,putstrike)<< "r " << r.getIntpRate(1.0) << " q " << q.getIntpRate(1.0) <<  std::endl;
	//std::cout <<"ecall: "<< ecall.pv(para)<< "s= " <<spot<<" "<<" vol " <<volat.getInpVol(365/365,callstrike)<< " r " << r.getIntpRate(1.0) << " q " << q.getIntpRate(1.0) << std::endl;
	std::vector<double> rs = EurPut.GetResult();
	std::vector<double> rs2 = EurPut2.GetResult();
	double bs_put_value = k_fmla_BSPut(spot, putstrike, rf_for_bs, div_for_bs, vol_bs, (exd - vd) / 365.0);
	double bs_put_vega = k_fmla_BSVega(spot, putstrike, rf_for_bs, div_for_bs, vol_bs, (exd - vd) / 365.0);

	std::cout << "pv by calc1 localvol r,q term " << rs[0] << "=%price " << rs[0] / spot * 100 << "%" << std::endl;
	std::cout << "pv by calc2 localvol r,q term " << rs2[0] << "=%price " << rs2[0] / spot * 100 << "%" << std::endl;
	std::cout << "BS vol=" << vol_bs << "=" << vol_bs * 100 << "%" << std::endl;
	cout << "BS put value(closed) " << bs_put_value << " error/spot " << (rs[0] - bs_put_value) / spot << "=" << (rs[0] - bs_put_value) / spot * 10000 << " bp" << endl;
	cout << "BS put vega(%)/spot " << bs_put_vega / 100.0 / spot << "=" << bs_put_vega * 100.0 / spot << " bp" << endl;

	//////////////////////////
	cout << "\n FDM���� Flat vol pricing\n";
	//double vol_term[] = { 0.08493150,0.16712330,0.25205480,0.50410960,0.74794520,1.00000000,1.50410960,2.00273970,2.50684930,3.00273970 }; //10terms
	//double vol_strike[] = { 178.332,193.193,208.054,222.915,237.776,252.637,267.498,282.359,297.22,312.081,326.942,341.803,356.664,371.525,386.386,401.247,416.108 };//17spot
	Vol volat_flat(10, 17);
	double t0_flat[] = { vol_bs,vol_bs,vol_bs,vol_bs,vol_bs,vol_bs,vol_bs,vol_bs,vol_bs,vol_bs,vol_bs,vol_bs,vol_bs,vol_bs,vol_bs,vol_bs,vol_bs };

	volat_flat.set_vol_strike(vol_strike, 17);
	volat_flat.set_vol_term(vol_term, 10);

	volat_flat.set_volsurface_by_term(t0_flat, 0, 17);
	volat_flat.set_volsurface_by_term(t0_flat, 1, 17);
	volat_flat.set_volsurface_by_term(t0_flat, 2, 17);
	volat_flat.set_volsurface_by_term(t0_flat, 3, 17);
	volat_flat.set_volsurface_by_term(t0_flat, 4, 17);
	volat_flat.set_volsurface_by_term(t0_flat, 5, 17);
	volat_flat.set_volsurface_by_term(t0_flat, 6, 17);
	volat_flat.set_volsurface_by_term(t0_flat, 7, 17);
	volat_flat.set_volsurface_by_term(t0_flat, 8, 17);
	volat_flat.set_volsurface_by_term(t0_flat, 9, 17);

	MarketParam para_flat(vd, spot, volat_flat, r, q);

	EuropeanOption EurPut_flat(refprice, exd, putpay);
	EuropeanOption EurPut2_flat(refprice, exd, putpay);
	EurPut_flat.Calc(para_flat);
	EurPut2_flat.Calc2(para_flat);
	std::vector<double> rs_flat = EurPut_flat.GetResult();
	std::vector<double> rs2_flat = EurPut2_flat.GetResult();
	std::cout << "pv by calc1 flat_vol r,q term struct " << rs_flat[0] << "=%price " << rs_flat[0] / spot * 100 << "%" << std::endl;
	std::cout << "pv by calc2 flat_vol r,q term struct " << rs2_flat[0] << "=%price " << rs2_flat[0] / spot * 100 << "%" << std::endl;
	cout << "flat vs surface �������̴� 2bp�������� ��ȣ��\n";

	////////////////////////////////
	cout << "\n FDM���� Flat vol, flat r,div curve pricing\n";
	double arr_r_flat[15];
	fill_n(arr_r_flat, 15, rf_for_bs);

	double arr_q_flat[42];
	fill_n(arr_q_flat, 42, div_for_bs);

	std::vector<double> v_r_flat(std::begin(arr_r_flat), std::end(arr_r_flat));
	std::vector<double> v_q_flat(std::begin(arr_q_flat), std::end(arr_q_flat));

	Rate r_flat(v_r_flat, v_rts);
	Rate q_flat(v_q_flat, v_qts);

	MarketParam para_volflat_rqflat(vd, spot, volat_flat, r_flat, q_flat);
	EurPut_flat.Calc(para_volflat_rqflat);
	EurPut2_flat.Calc2(para_volflat_rqflat);

	std::vector<double> rs_flat_rqflat = EurPut_flat.GetResult();
	std::vector<double> rs2_flat_rqflat = EurPut2_flat.GetResult();
	std::cout << "pv by calc1 flat vol,r,q  " << rs_flat_rqflat[0] << "=%price " << rs_flat_rqflat[0] / spot * 100 << "%" << std::endl;
	std::cout << "pv by calc2 flat vol,r,q  " << rs2_flat_rqflat[0] << "=%price " << rs2_flat_rqflat[0] / spot * 100 << "%" << std::endl;
	cout << "vol,r,q,flat vs surface �������̴� 3bp(2bp from vol, 1bp from rq) �������� ��ȣ��\n";

}



int main()
{	
	/*test cal1 vs calc2 for vanilla option*/
	test_calc1_vs_calc2_for_vanilla();

	/*test for mc vanilla	*/
	//test_calc2_mc_for_vanilla(30000);

	/*test calc2 for param vs params vanilla	*/
	//test_calc2_for_vanilla_param_params();


	/*test for div transform*/
	//test_dividend();


	/*Test autocall Clac1 vs Calc2, for loop improvment*/
	//test_Cal1_vs_Calc2();
	

	/*Value autocall analysis between FD and MC*/ 
	//test_compare_fd_mc();







	//long numMc = strtol(argv[1],nullptr, 10);
	//test_dividend();
	//test_european_discrete_localvol(spot);
	//test_asian(spot);
	//test_europeanMC(spot);
	//test_european(spot, numMc);
	//test_asian(spot, numMc);
	//test_american(spot);
	//test_european(spot);
	//test_european(spot*1.05);
	//test_barrier_flat(spot);
	//test_barrier_LV(spot);
	//test_autocall(spot,1);
	//test_autocall_div(spot, 1);
	//auto ms1 = duration_cast<milliseconds>(system_clock::now().time_since_epoch()).count();
	//test_autocall(spot,0,surface,calc1);  //pv hitted 0.98996 
	//auto  ms2 = duration_cast<milliseconds>(system_clock::now().time_since_epoch()).count();
	//std::cout << ms2 - ms1 << " calc1 millisecons last." << std::endl;
	//auto ms3 = duration_cast<milliseconds>(system_clock::now().time_since_epoch()).count();
	//test_autocall(spot+6.0, 0, surface,calc1);  //pv hitted 0.98996 
	//auto  ms4 = duration_cast<milliseconds>(system_clock::now().time_since_epoch()).count();
	//std::cout << ms4 - ms3 << " calc1 millisecons last." << std::endl;
	//auto ms1_2 = duration_cast<milliseconds>(system_clock::now().time_since_epoch()).count();
	//test_autocall(spot, 0, surface,calc2);  //pv hitted 0.98996 
	//auto  ms2_2 = duration_cast<milliseconds>(system_clock::now().time_since_epoch()).count();
	//std::cout << ms2_2 - ms1_2 << "calc2 millisecons last." << std::endl;
	//auto ms5 = duration_cast<milliseconds>(system_clock::now().time_since_epoch());
	//test_autocall_mc(spot, 1, 300000, surface);//
	//auto ms6 = duration_cast<milliseconds>(system_clock::now().time_since_epoch());
	//std::cout <<"duration : " << (ms6.count() - ms5.count())/1000.0 <<std::endl;
	//auto ms7 = duration_cast<milliseconds>(system_clock::now().time_since_epoch());
	//test_autocall_mc2(spot+6.0,1, 20000, surface);//
	//auto ms8 = duration_cast<milliseconds>(system_clock::now().time_since_epoch());
	//std::cout << ms8.count() - ms7.count() << "millisecons last." << std::endl;
	//test_autocall_flatvol(spot, 1);
	//test_autocall_mc_flatvol(spot,1,30000);
	//PayoffBarCUO c(100, 100, 1);
	//TEST 2019.8.19
	//FDM interpolation optimization calc vs calc_old
	//simple market param
	//test_autocall_simple(spot, 1, surface, calc)(

	return 0;
}